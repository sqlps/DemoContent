-- ================================ Start of versioning demo - Session 1

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

-- reset workload
USE AdventureWorks2012
GO
SET NOCOUNT ON
GO
EXEC Demo.usp_DemoReset
GO

-- show locks for updates
BEGIN TRAN
-- update disk-based table
	UPDATE Sales.SalesOrderHeader_ondisk
    SET Status=9
	WHERE SalesOrderID=67333

-- update memory-optimized table
	UPDATE Sales.SalesOrderHeader_inmem
    SET Status=9
	WHERE SalesOrderID=67333

-- show locks
	SELECT case when resource_type='OBJECT' then object_name(resource_associated_entity_id) else NULL end as 'table', 
		resource_type, resource_description, request_mode, request_type, request_owner_type 
	FROM sys.dm_tran_locks

-- show properties of XTP transaction
	SELECT 
		xtp_transaction_id,
		transaction_id,
		session_id,
		begin_tsn,
		end_tsn,
		state,
		state_desc,
		result,
		result_desc,
		read_set_row_count,
		write_set_row_count,
		scan_set_count,
		log_bytes_required
	FROM sys.dm_db_xtp_transactions

-- commit transaction
COMMIT
GO

-- validate updated status
SELECT SalesOrderID, Status
FROM Sales.SalesOrderHeader_ondisk
WHERE SalesOrderID=67333

SELECT SalesOrderID, Status
FROM Sales.SalesOrderHeader_inmem
WHERE SalesOrderID=67333
GO

-- verify transaction status
SELECT 
	xtp_transaction_id,
	transaction_id,
	session_id,
	begin_tsn,
	end_tsn,
	state,
	state_desc,
	result,
	result_desc,
	read_set_row_count,
	write_set_row_count,
	scan_set_count,
	log_bytes_required
FROM sys.dm_db_xtp_transactions
GO

-- ===================== transactions and native procs

-- create native proc 
CREATE PROCEDURE dbo.UpdateSalesOrderStatus @SalesOrderID int, @Status tinyint
  WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS 
BEGIN ATOMIC WITH 
(	TRANSACTION ISOLATION LEVEL = SNAPSHOT,
	LANGUAGE = N'us_english')

	UPDATE Sales.SalesOrderHeader_inmem
    SET Status=@Status
	WHERE SalesOrderID=@SalesOrderID

END
GO

-- run native proc
EXEC dbo.UpdateSalesOrderStatus 67333, 10
GO

-- verify transaction status
SELECT 
	xtp_transaction_id,
	transaction_id,
	session_id,
	begin_tsn,
	end_tsn,
	state,
	state_desc,
	result,
	result_desc,
	read_set_row_count,
	write_set_row_count,
	scan_set_count,
	log_bytes_required
FROM sys.dm_db_xtp_transactions
GO

-- native proc in user transaction
BEGIN TRAN
	EXEC dbo.UpdateSalesOrderStatus 67333, 11

	-- verify transaction status
	SELECT 
		xtp_transaction_id,
		transaction_id,
		session_id,
		begin_tsn,
		end_tsn,
		state,
		state_desc,
		result,
		result_desc,
		read_set_row_count,
		write_set_row_count,
		scan_set_count,
		log_bytes_required
	FROM sys.dm_db_xtp_transactions

-- show locks -- observe no locks at all on the table, not even Sch-S!
	SELECT case when resource_type='OBJECT' then object_name(resource_associated_entity_id) else NULL end as 'table', 
		resource_type, resource_description, request_mode, request_type, request_owner_type 
	FROM sys.dm_tran_locks

-- commit
COMMIT


-- ================== SERIALIZABLE isolation

BEGIN TRAN
-- read from disk-based table
	SELECT ProductID, so.*
	FROM Sales.SpecialOffer_ondisk so WITH (SERIALIZABLE) JOIN Sales.SpecialOfferProduct sop WITH (SERIALIZABLE) ON so.SpecialOfferID=sop.SpecialOfferID
	WHERE so.SpecialOfferID=9

-- show locks
	SELECT case when resource_type='OBJECT' then object_name(resource_associated_entity_id) else NULL end as 'table', 
		resource_type, resource_description, request_mode, request_type, request_owner_type , *
	FROM sys.dm_tran_locks
COMMIT
GO



BEGIN TRAN
-- read from memory-optimized table
	SELECT ProductID, so.*
	FROM Sales.SpecialOffer_inmem so WITH (SERIALIZABLE) JOIN Sales.SpecialOfferProduct_inmem sop WITH (SERIALIZABLE) ON so.SpecialOfferID=sop.SpecialOfferID
	WHERE so.SpecialOfferID=9


-- show locks
	SELECT case when resource_type='OBJECT' then object_name(resource_associated_entity_id) else NULL end as 'table', 
		resource_type, resource_description, request_mode, request_type, request_owner_type 
	FROM sys.dm_tran_locks

-- show properties of XTP transaction
	SELECT 
		xtp_transaction_id,
		transaction_id,
		session_id,
		begin_tsn,
		end_tsn,
		state,
		state_desc,
		result,
		result_desc,
		read_set_row_count,
		write_set_row_count,
		scan_set_count,
		log_bytes_required
	FROM sys.dm_db_xtp_transactions

-- commit transaction
COMMIT
GO
