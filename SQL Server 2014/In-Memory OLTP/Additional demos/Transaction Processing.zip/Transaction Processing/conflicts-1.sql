-- ================================ Start of conflicts demo - Session 1

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

-- reset workload
USE AdventureWorks2012
GO
SET NOCOUNT ON
GO
EXEC Demo.usp_DemoReset
GO

-- update disk-based table
--step 1
BEGIN TRAN
	UPDATE Sales.SalesOrderHeader_ondisk
    SET Status=6 
    WHERE SalesOrderID=67333
--step 3
COMMIT
GO

-- verify status in DB
SELECT SalesOrderID, Status
FROM Sales.SalesOrderHeader_ondisk
WHERE SalesOrderID=67333
GO

-- update memory-optimized table
--step 1
BEGIN TRAN
	UPDATE Sales.SalesOrderHeader_inmem
    SET Status=6 
    WHERE SalesOrderID=67333
--step 3
COMMIT
GO

-- verify status in DB
SELECT SalesOrderID, Status
FROM Sales.SalesOrderHeader_inmem
WHERE SalesOrderID=67333
GO

-- memory-optimized REPEATABLEREAD validation failure
-- TxA
-- step 1
BEGIN TRAN
	SELECT SalesOrderID, Status 
	FROM Sales.SalesOrderHeader_inmem WITH (REPEATABLEREAD)
    WHERE SalesOrderID=67333

	-- verify read-set
	SELECT 
		xtp_transaction_id,
		transaction_id,
		session_id,
		begin_tsn,
		end_tsn,
		state,
		state_desc,
		read_set_row_count,
		write_set_row_count
	FROM sys.dm_db_xtp_transactions
	WHERE session_id=@@SPID and state=0

-- step 3
	UPDATE Sales.SalesOrderHeader_inmem WITH (REPEATABLEREAD)
    SET Status=9 
    WHERE SalesOrderID=67334

	-- verify read-set, write-set
	SELECT 
		xtp_transaction_id,
		transaction_id,
		session_id,
		begin_tsn,
		end_tsn,
		state,
		state_desc,
		read_set_row_count,
		write_set_row_count
	FROM sys.dm_db_xtp_transactions
	WHERE session_id=@@SPID and state=0

-- step 5
COMMIT
GO

