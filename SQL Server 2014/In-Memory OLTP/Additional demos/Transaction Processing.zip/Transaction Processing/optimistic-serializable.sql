-- ================== reset demo

exec Demo.usp_DemoReset
go


-- ================== verify all SalesOrderIDs in the range exist

declare @minID int = 43659
declare @maxID int = 75123
declare @i int = @minID

while @i <= @maxID
begin
	if not exists (select SalesOrderID from Sales.SalesOrderHeader_inmem where SalesOrderID=@i)
		select @i

	set @i += 1
end
go

-- ================= validate range of products for demo

declare @minID int = 706
declare @maxID int = 999
declare @i int = @minID

while @i <= @maxID
begin
	if not exists (select ProductID from Demo.DemoSalesOrderDetailSeed where ProductID=@i)
		select @i

	set @i += 1
end
go


select cast(rand() * 100 + 43659 as int)


/********************** 
basic scenario:
change special offers at a rapid pace (insert/delete)
need to ensure you always use only and exactly the special offers available to you (serializable)

Four variations of the workload:
1. disk-based with RC
2. in-memory OLTP with snapshot
3. disk-based with serializable
4. in-memory OLTP with serializable
*************/

-- ==================== update primary key for SalesOrderDetail table to pre-empt deadlocks

select * from sys.indexes where object_id=object_id('Sales.SalesOrderDetail_ondisk')
ALTER TABLE Sales.SalesOrderDetail_ondisk
DROP CONSTRAINT ODPK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID
GO

ALTER TABLE Sales.SalesOrderDetail_ondisk
ADD CONSTRAINT ODPK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID 
	PRIMARY KEY CLUSTERED (SalesOrderDetailID, SalesOrderID)
GO

select * from sys.indexes where object_id=object_id('Sales.SalesOrderDetail_ondisk')

drop index Sales.SalesOrderDetail_ondisk.IX_ProductID

select * from sys.dm_exec_requests

/***** update procs to work with special offers ******/


-- insert sales order in disk-based tables 
IF object_id('Sales.usp_InsertSalesOrder_ondisk_ser') IS NOT NULL
	DROP PROCEDURE Sales.usp_InsertSalesOrder_ondisk_ser 
GO
CREATE PROCEDURE [Sales].usp_InsertSalesOrder_ondisk_ser
	@SalesOrderID int OUTPUT,
	@DueDate [datetime2](7) ,
	@CustomerID [int] ,
	@BillToAddressID [int] ,
	@ShipToAddressID [int] ,
	@ShipMethodID [int] ,
	@SalesOrderDetails Sales.SalesOrderDetailType_ondisk READONLY,
	@Status [tinyint]  = 1,
	@OnlineOrderFlag [bit] = 1,
	@PurchaseOrderNumber [nvarchar](25) = NULL,
	@AccountNumber [nvarchar](15) = NULL,
	@SalesPersonID [int] = -1,
	@TerritoryID [int] = NULL,
	@CreditCardID [int] = NULL,
	@CreditCardApprovalCode [varchar](15) = NULL,
	@CurrencyRateID [int] = NULL,
	@Comment nvarchar(128) = NULL
AS
BEGIN 
	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
	BEGIN TRAN
	
		DECLARE @OrderDate datetime2 = sysdatetime()

		DECLARE @SubTotal money = 0


		INSERT INTO Sales.SalesOrderHeader_ondisk
		(	DueDate,
			Status,
			OnlineOrderFlag,
			PurchaseOrderNumber,
			AccountNumber,
			CustomerID,
			SalesPersonID,
			TerritoryID,
			BillToAddressID,
			ShipToAddressID,
			ShipMethodID,
			CreditCardID,
			CreditCardApprovalCode,
			CurrencyRateID,
			Comment,
			OrderDate,
			SubTotal,
			ModifiedDate)
		VALUES
		(	
			@DueDate,
			@Status,
			@OnlineOrderFlag,
			@PurchaseOrderNumber,
			@AccountNumber,
			@CustomerID,
			@SalesPersonID,
			@TerritoryID,
			@BillToAddressID,
			@ShipToAddressID,
			@ShipMethodID,
			@CreditCardID,
			@CreditCardApprovalCode,
			@CurrencyRateID,
			@Comment,
			@OrderDate,
			@SubTotal,
			@OrderDate
		)

		SET @SalesOrderID = SCOPE_IDENTITY()

		INSERT INTO Sales.SalesOrderDetail_ondisk
		(
			SalesOrderID,
			OrderQty,
			ProductID,
			SpecialOfferID,
			UnitPrice,
			UnitPriceDiscount,
			ModifiedDate
		)
		SELECT 
			@SalesOrderID,
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice,
			p.ListPrice * SUM(so.DiscountPct),
			@OrderDate
		FROM @SalesOrderDetails od JOIN Production.Product_ondisk p on od.ProductID=p.ProductID
			JOIN Sales.SpecialOfferProduct sop on p.ProductID=sop.ProductID
			JOIN Sales.SpecialOffer_ondisk so on sop.SpecialOfferID=so.SpecialOfferID
			
		GROUP BY 
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice

		SELECT @SubTotal = SUM(UnitPrice - UnitPriceDiscount)
		FROM Sales.SalesOrderDetail_ondisk
		WHERE SalesOrderID = @SalesOrderID

		UPDATE Sales.SalesOrderHeader_ondisk
		SET SubTotal=@SubTotal
		WHERE SalesOrderID=@SalesOrderID


	COMMIT
END
GO



-- native procedure create
IF object_id('Sales.usp_InsertSalesOrder_inmem_ser') IS NOT NULL
	DROP PROCEDURE Sales.usp_InsertSalesOrder_inmem_ser 
GO
CREATE PROCEDURE [Sales].usp_InsertSalesOrder_inmem_ser
	@SalesOrderID int OUTPUT,
	@DueDate [datetime2](7) NOT NULL,
	@CustomerID [int] NOT NULL,
	@BillToAddressID [int] NOT NULL,
	@ShipToAddressID [int] NOT NULL,
	@ShipMethodID [int] NOT NULL,
	@SalesOrderDetails Sales.SalesOrderDetailType_inmem READONLY,
	@Status [tinyint] NOT NULL = 1,
	@OnlineOrderFlag [bit] NOT NULL = 1,
	@PurchaseOrderNumber [nvarchar](25) = NULL,
	@AccountNumber [nvarchar](15) = NULL,
	@SalesPersonID [int] NOT NULL = -1,
	@TerritoryID [int] = NULL,
	@CreditCardID [int] = NULL,
	@CreditCardApprovalCode [varchar](15) = NULL,
	@CurrencyRateID [int] = NULL,
	@Comment nvarchar(128) = NULL
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH
  (TRANSACTION ISOLATION LEVEL = SERIALIZABLE,
   LANGUAGE = N'us_english')

		DECLARE @OrderDate datetime2 = sysdatetime()

		DECLARE @SubTotal money = 0


		INSERT INTO Sales.SalesOrderHeader_inmem
		(	DueDate,
			Status,
			OnlineOrderFlag,
			PurchaseOrderNumber,
			AccountNumber,
			CustomerID,
			SalesPersonID,
			TerritoryID,
			BillToAddressID,
			ShipToAddressID,
			ShipMethodID,
			CreditCardID,
			CreditCardApprovalCode,
			CurrencyRateID,
			Comment,
			OrderDate,
			SubTotal,
			ModifiedDate)
		VALUES
		(	
			@DueDate,
			@Status,
			@OnlineOrderFlag,
			@PurchaseOrderNumber,
			@AccountNumber,
			@CustomerID,
			@SalesPersonID,
			@TerritoryID,
			@BillToAddressID,
			@ShipToAddressID,
			@ShipMethodID,
			@CreditCardID,
			@CreditCardApprovalCode,
			@CurrencyRateID,
			@Comment,
			@OrderDate,
			@SubTotal,
			@OrderDate
		)

		SET @SalesOrderID = SCOPE_IDENTITY()

		INSERT INTO Sales.SalesOrderDetail_inmem
		(
			SalesOrderID,
			OrderQty,
			ProductID,
			SpecialOfferID,
			UnitPrice,
			UnitPriceDiscount,
			ModifiedDate
		)
		SELECT 
			@SalesOrderID,
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice,
			p.ListPrice * SUM(so.DiscountPct),
			@OrderDate
		FROM @SalesOrderDetails od JOIN Production.Product_inmem p on od.ProductID=p.ProductID
			JOIN Sales.SpecialOfferProduct_inmem sop on p.ProductID=sop.ProductID
			JOIN Sales.SpecialOffer_inmem so on sop.SpecialOfferID=so.SpecialOfferID
		GROUP BY 
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice

		SELECT @SubTotal = SUM(UnitPrice - UnitPriceDiscount)
		FROM Sales.SalesOrderDetail_inmem
		WHERE SalesOrderID = @SalesOrderID

		UPDATE Sales.SalesOrderHeader_inmem
		SET SubTotal=@SubTotal
		WHERE SalesOrderID=@SalesOrderID

END
GO


-- insert sales order in disk-based tables 
IF object_id('Sales.usp_InsertSalesOrder_ondisk_rc') IS NOT NULL
	DROP PROCEDURE Sales.usp_InsertSalesOrder_ondisk_rc 
GO
CREATE PROCEDURE [Sales].usp_InsertSalesOrder_ondisk_rc
	@SalesOrderID int OUTPUT,
	@DueDate [datetime2](7) ,
	@CustomerID [int] ,
	@BillToAddressID [int] ,
	@ShipToAddressID [int] ,
	@ShipMethodID [int] ,
	@SalesOrderDetails Sales.SalesOrderDetailType_ondisk READONLY,
	@Status [tinyint]  = 1,
	@OnlineOrderFlag [bit] = 1,
	@PurchaseOrderNumber [nvarchar](25) = NULL,
	@AccountNumber [nvarchar](15) = NULL,
	@SalesPersonID [int] = -1,
	@TerritoryID [int] = NULL,
	@CreditCardID [int] = NULL,
	@CreditCardApprovalCode [varchar](15) = NULL,
	@CurrencyRateID [int] = NULL,
	@Comment nvarchar(128) = NULL
AS
BEGIN 
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	BEGIN TRAN
	
		DECLARE @OrderDate datetime2 = sysdatetime()

		DECLARE @SubTotal money = 0


		INSERT INTO Sales.SalesOrderHeader_ondisk
		(	DueDate,
			Status,
			OnlineOrderFlag,
			PurchaseOrderNumber,
			AccountNumber,
			CustomerID,
			SalesPersonID,
			TerritoryID,
			BillToAddressID,
			ShipToAddressID,
			ShipMethodID,
			CreditCardID,
			CreditCardApprovalCode,
			CurrencyRateID,
			Comment,
			OrderDate,
			SubTotal,
			ModifiedDate)
		VALUES
		(	
			@DueDate,
			@Status,
			@OnlineOrderFlag,
			@PurchaseOrderNumber,
			@AccountNumber,
			@CustomerID,
			@SalesPersonID,
			@TerritoryID,
			@BillToAddressID,
			@ShipToAddressID,
			@ShipMethodID,
			@CreditCardID,
			@CreditCardApprovalCode,
			@CurrencyRateID,
			@Comment,
			@OrderDate,
			@SubTotal,
			@OrderDate
		)

		SET @SalesOrderID = SCOPE_IDENTITY()

		INSERT INTO Sales.SalesOrderDetail_ondisk
		(
			SalesOrderID,
			OrderQty,
			ProductID,
			SpecialOfferID,
			UnitPrice,
			UnitPriceDiscount,
			ModifiedDate
		)
		SELECT 
			@SalesOrderID,
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice,
			p.ListPrice * SUM(so.DiscountPct),
			@OrderDate
		FROM @SalesOrderDetails od JOIN Production.Product_ondisk p on od.ProductID=p.ProductID
			JOIN Sales.SpecialOfferProduct sop on p.ProductID=sop.ProductID
			JOIN Sales.SpecialOffer_ondisk so on sop.SpecialOfferID=so.SpecialOfferID
			
		GROUP BY 
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice

		SELECT @SubTotal = SUM(UnitPrice - UnitPriceDiscount)
		FROM Sales.SalesOrderDetail_ondisk
		WHERE SalesOrderID = @SalesOrderID

		UPDATE Sales.SalesOrderHeader_ondisk
		SET SubTotal=@SubTotal
		WHERE SalesOrderID=@SalesOrderID


	COMMIT
END
GO



-- native procedure create
IF object_id('Sales.usp_InsertSalesOrder_inmem_si') IS NOT NULL
	DROP PROCEDURE Sales.usp_InsertSalesOrder_inmem_si 
GO
CREATE PROCEDURE [Sales].usp_InsertSalesOrder_inmem_si
	@SalesOrderID int OUTPUT,
	@DueDate [datetime2](7) NOT NULL,
	@CustomerID [int] NOT NULL,
	@BillToAddressID [int] NOT NULL,
	@ShipToAddressID [int] NOT NULL,
	@ShipMethodID [int] NOT NULL,
	@SalesOrderDetails Sales.SalesOrderDetailType_inmem READONLY,
	@Status [tinyint] NOT NULL = 1,
	@OnlineOrderFlag [bit] NOT NULL = 1,
	@PurchaseOrderNumber [nvarchar](25) = NULL,
	@AccountNumber [nvarchar](15) = NULL,
	@SalesPersonID [int] NOT NULL = -1,
	@TerritoryID [int] = NULL,
	@CreditCardID [int] = NULL,
	@CreditCardApprovalCode [varchar](15) = NULL,
	@CurrencyRateID [int] = NULL,
	@Comment nvarchar(128) = NULL
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH
  (TRANSACTION ISOLATION LEVEL = SNAPSHOT,
   LANGUAGE = N'us_english')

		DECLARE @OrderDate datetime2 = sysdatetime()

		DECLARE @SubTotal money = 0


		INSERT INTO Sales.SalesOrderHeader_inmem
		(	DueDate,
			Status,
			OnlineOrderFlag,
			PurchaseOrderNumber,
			AccountNumber,
			CustomerID,
			SalesPersonID,
			TerritoryID,
			BillToAddressID,
			ShipToAddressID,
			ShipMethodID,
			CreditCardID,
			CreditCardApprovalCode,
			CurrencyRateID,
			Comment,
			OrderDate,
			SubTotal,
			ModifiedDate)
		VALUES
		(	
			@DueDate,
			@Status,
			@OnlineOrderFlag,
			@PurchaseOrderNumber,
			@AccountNumber,
			@CustomerID,
			@SalesPersonID,
			@TerritoryID,
			@BillToAddressID,
			@ShipToAddressID,
			@ShipMethodID,
			@CreditCardID,
			@CreditCardApprovalCode,
			@CurrencyRateID,
			@Comment,
			@OrderDate,
			@SubTotal,
			@OrderDate
		)

		SET @SalesOrderID = SCOPE_IDENTITY()

		INSERT INTO Sales.SalesOrderDetail_inmem
		(
			SalesOrderID,
			OrderQty,
			ProductID,
			SpecialOfferID,
			UnitPrice,
			UnitPriceDiscount,
			ModifiedDate
		)
		SELECT 
			@SalesOrderID,
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice,
			p.ListPrice * SUM(so.DiscountPct),
			@OrderDate
		FROM @SalesOrderDetails od JOIN Production.Product_inmem p on od.ProductID=p.ProductID
			JOIN Sales.SpecialOfferProduct_inmem sop on p.ProductID=sop.ProductID
			JOIN Sales.SpecialOffer_inmem so on sop.SpecialOfferID=so.SpecialOfferID
		GROUP BY 
			od.OrderQty,
			od.ProductID,
			od.SpecialOfferID,
			p.ListPrice

		SELECT @SubTotal = SUM(UnitPrice - UnitPriceDiscount)
		FROM Sales.SalesOrderDetail_inmem
		WHERE SalesOrderID = @SalesOrderID

		UPDATE Sales.SalesOrderHeader_inmem
		SET SubTotal=@SubTotal
		WHERE SalesOrderID=@SalesOrderID

END
GO


/**************** insert some items ***************/



-- disk-based read committed
SET NOCOUNT ON
GO
declare @start datetime2
set @start = SYSDATETIME()

DECLARE 
	@i int = 0, 
	@od Sales.SalesOrderDetailType_ondisk, 
	@SalesOrderID int, 
	@DueDate datetime2 = sysdatetime(), 
	@CustomerID int = rand() * 8000, 
	@BillToAddressID int = rand() * 10000, 
	@ShipToAddressID int = rand() * 10000, 
	@ShipMethodID int = (rand() * 5) + 1; 

INSERT INTO @od 
SELECT OrderQty, ProductID, SpecialOfferID 
FROM Demo.DemoSalesOrderDetailSeed 
WHERE OrderID= cast((rand()*106) + 1 as int); 

WHILE (@i < 20000) 
BEGIN; 
	EXEC Sales.usp_InsertSalesOrder_ondisk_rc @SalesOrderID OUTPUT, @DueDate, @CustomerID, @BillToAddressID, @ShipToAddressID, @ShipMethodID, @od; 
	SET @i += 1 
END
select datediff(ms,@start, sysdatetime()) as 'disk-based READ COMMITTED elapse time in ms'
GO



-- memory-optimized snapshot
declare @start datetime2
set @start = SYSDATETIME()

DECLARE 
	@i int = 0, 
	@od Sales.SalesOrderDetailType_inmem, 
	@SalesOrderID int, 
	@DueDate datetime2 = sysdatetime(), 
	@CustomerID int = rand() * 8000, 
	@BillToAddressID int = rand() * 10000, 
	@ShipToAddressID int = rand() * 10000, 
	@ShipMethodID int = (rand() * 5) + 1; 

INSERT INTO @od 
SELECT OrderQty, ProductID, SpecialOfferID 
FROM Demo.DemoSalesOrderDetailSeed 
WHERE OrderID= cast((rand()*106) + 1 as int); 

WHILE (@i < 20000) 
BEGIN; 
	EXEC Sales.usp_InsertSalesOrder_inmem_si @SalesOrderID OUTPUT, @DueDate, @CustomerID, @BillToAddressID, @ShipToAddressID, @ShipMethodID, @od; 
	SET @i += 1 
END
select datediff(ms,@start, sysdatetime()) as 'memory-optimized SNAPSHOT elapse time in ms'
GO

-- disk-based serializable
SET NOCOUNT ON
GO
declare @start datetime2
set @start = SYSDATETIME()

DECLARE 
	@i int = 0, 
	@od Sales.SalesOrderDetailType_ondisk, 
	@SalesOrderID int, 
	@DueDate datetime2 = sysdatetime(), 
	@CustomerID int = rand() * 8000, 
	@BillToAddressID int = rand() * 10000, 
	@ShipToAddressID int = rand() * 10000, 
	@ShipMethodID int = (rand() * 5) + 1; 

INSERT INTO @od 
SELECT OrderQty, ProductID, SpecialOfferID 
FROM Demo.DemoSalesOrderDetailSeed 
WHERE OrderID= cast((rand()*106) + 1 as int); 

WHILE (@i < 20000) 
BEGIN; 
	EXEC Sales.usp_InsertSalesOrder_ondisk_ser @SalesOrderID OUTPUT, @DueDate, @CustomerID, @BillToAddressID, @ShipToAddressID, @ShipMethodID, @od; 
	SET @i += 1 
END
select datediff(ms,@start, sysdatetime()) as 'disk-based SERIALIZABLE elapse time in ms'
GO



-- memory-optimized serializable
declare @start datetime2
set @start = SYSDATETIME()

DECLARE 
	@i int = 0, 
	@od Sales.SalesOrderDetailType_inmem, 
	@SalesOrderID int, 
	@DueDate datetime2 = sysdatetime(), 
	@CustomerID int = rand() * 8000, 
	@BillToAddressID int = rand() * 10000, 
	@ShipToAddressID int = rand() * 10000, 
	@ShipMethodID int = (rand() * 5) + 1; 

INSERT INTO @od 
SELECT OrderQty, ProductID, SpecialOfferID 
FROM Demo.DemoSalesOrderDetailSeed 
WHERE OrderID= cast((rand()*106) + 1 as int); 

WHILE (@i < 20000) 
BEGIN; 
	EXEC Sales.usp_InsertSalesOrder_inmem_ser @SalesOrderID OUTPUT, @DueDate, @CustomerID, @BillToAddressID, @ShipToAddressID, @ShipMethodID, @od; 
	SET @i += 1 
END
select datediff(ms,@start, sysdatetime()) as 'memory-optimized SERIALIZABLE elapse time in ms'
GO


-- ======= run ostress

--inmem
-- ostress.exe �n100 �r100 -S. -E -dAdventureWorks2012 -q -ic:\TR19\insertsalesorders_inmem_si.sql
-- ostress.exe �n100 �r100 -S. -E -dAdventureWorks2012 -q -ic:\TR19\insertsalesorders_inmem_ser.sql

--ondisk
-- ostress.exe �n100 �r100 -S. -E -dAdventureWorks2012 -q -ic:\TR19\insertsalesorders_ondisk_rc.sql
-- ostress.exe �n100 �r100 -S. -E -dAdventureWorks2012 -q -ic:\TR19\insertsalesorders_ondisk_ser.sql
