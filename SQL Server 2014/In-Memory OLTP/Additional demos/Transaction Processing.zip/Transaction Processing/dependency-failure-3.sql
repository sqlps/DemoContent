-- ================================ Start of dependency failure demo - Session 3

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

-- reset workload
USE AdventureWorks2012
GO
SET NOCOUNT ON
GO



DECLARE @i bigint
BEGIN TRY
	WHILE (1=1)
	BEGIN
		SELECT @i = counter 
		FROM dbo.dep_demo
		WHERE id=1
	END
END TRY
BEGIN CATCH
	PRINT N'value of counter: ' + cast(@i as nvarchar)
	PRINT N' Error ' + cast(error_number() as nvarchar) + N': ' + error_message()
END CATCH

-- query transaction map to find dependency failures
select 
	original.xtp_transaction_id as 'original transaction id',
	original.state_desc as 'original transaction state',
	original.result_desc as 'original transaction result',
	dependent.xtp_transaction_id as 'dependent transaction id',
	dependent.state_desc as 'dependent transaction state',
	dependent.result_desc as 'dependent transaction result'
from sys.dm_db_xtp_transactions original
	join sys.dm_db_xtp_transactions dependent 
	on original.dependent_1_address = dependent.memory_address
where original.state not in (0, 1, 3)
order by xtp_transaction_id desc
GO

