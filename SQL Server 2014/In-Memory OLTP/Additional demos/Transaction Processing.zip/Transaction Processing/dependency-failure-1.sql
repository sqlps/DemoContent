-- ================================ Start of dependency failure demo - Session 1

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

USE AdventureWorks2012
GO
SET NOCOUNT ON
GO
EXEC Demo.usp_DemoReset
GO

-- setup
IF object_id('dbo.dep_demo') is not null
	DROP TABLE dbo.dep_demo
GO
CREATE TABLE dbo.dep_demo
(
	id int not null primary key nonclustered,
	counter bigint not null
) with (memory_optimized=on)
GO

INSERT dbo.dep_demo VALUES (1,1)
GO

-- create serializable proc that performs large scan and increases counter
CREATE PROCEDURE dbo.ser_demo
  WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS 
BEGIN ATOMIC WITH 
(	TRANSACTION ISOLATION LEVEL = SERIALIZABLE,
	LANGUAGE = N'us_english')

	UPDATE dbo.dep_demo
    SET counter += 1
	WHERE id=1

	DECLARE @SalesOrderDetailID bigint

	SELECT @SalesOrderDetailID = SalesOrderDetailID
	FROM Sales.SalesOrderDetail_inmem

END
GO


-- main loop - catches expected errors
DECLARE @failurecount int = 0
WHILE (1=1)
  BEGIN
    BEGIN TRY

      EXEC dbo.ser_demo

    END TRY
    BEGIN CATCH
      IF (error_number() in (41302, 41305, 41325, 41301, 1205))
      BEGIN
		SET @failurecount += 1
		PRINT N'#' + cast(@failurecount as nvarchar) + N' Error ' + cast(error_number() as nvarchar) + N': ' + error_message()
      END
      ELSE
      BEGIN
        -- throw if this is not a qualifying error condition
        ;THROW
      END
    END CATCH
  END
GO


-- cleanup

DROP PROC dbo.ser_demo
DROP TABLE dbo.dep_demo
GO