-- ================================ Start of dependency failure demo - Session 2

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

USE AdventureWorks2012
GO
SET NOCOUNT ON
GO

-- introduce phantom rows in the SalesOrderDetail table
INSERT Sales.SalesOrderDetail_inmem
	(SalesOrderID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, ModifiedDate)
VALUES
	(74085, NULL, 1, 975, 1, 1700.99, 0, SYSDATETIME())

GO 100

-- verify transaction status
select * from sys.dm_db_xtp_transactions
where state <> 1
order by xtp_transaction_id desc
GO

-- helper commands:
--select * from sys.dm_exec_requests where session_id <> @@spid
-- kill 57