-- ================================ Start of interop query demo

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

-- reset workload
USE AdventureWorks2012
GO
SET NOCOUNT ON
GO
EXEC Demo.usp_DemoReset
GO

--query traditional tables

SELECT p.ProductID, sop.SpecialOfferID 
FROM Production.Product_ondisk p JOIN Sales.SpecialOfferProduct sop ON p.ProductID=sop.ProductID
GO

SET SHOWPLAN_XML ON
GO
SELECT p.ProductID, sop.SpecialOfferID 
FROM Production.Product_ondisk p JOIN Sales.SpecialOfferProduct sop ON p.ProductID=sop.ProductID
GO
SET SHOWPLAN_XML OFF
GO

--query memory-optimized tables

SELECT p.ProductID, sop.SpecialOfferID 
FROM Production.Product_inmem p JOIN Sales.SpecialOfferProduct_inmem sop ON p.ProductID=sop.ProductID
GO
SET SHOWPLAN_XML ON
GO
SELECT p.ProductID, sop.SpecialOfferID 
FROM Production.Product_inmem p JOIN Sales.SpecialOfferProduct_inmem sop ON p.ProductID=sop.ProductID
GO
SET SHOWPLAN_XML OFF
GO

-- guess: why are the plans different?


SELECT object_name(object_id), * FROM sys.indexes WHERE object_name(object_id) = 'SpecialOfferProduct'
SELECT object_name(object_id), * FROM sys.indexes WHERE object_name(object_id) = 'SpecialOfferProduct_inmem'
SELECT object_name(object_id), * FROM sys.indexes WHERE object_name(object_id) = 'Product_ondisk'
SELECT object_name(object_id), * FROM sys.indexes WHERE object_name(object_id) = 'Product_inmem'
GO


-- access both types of tables


SELECT p.ProductID, sop.SpecialOfferID 
FROM Production.Product_ondisk p JOIN Sales.SpecialOfferProduct_inmem sop ON p.ProductID=sop.ProductID
GO
SET SHOWPLAN_XML ON
GO
SELECT p.ProductID, sop.SpecialOfferID 
FROM Production.Product_ondisk p JOIN Sales.SpecialOfferProduct_inmem sop ON p.ProductID=sop.ProductID
GO
SET SHOWPLAN_XML OFF
GO


-- ============ end of interpreted T-SQL demo
