-- ============================= start of native query demo

-- sample database: [http://msdn.microsoft.com/en-us/library/dn511655.aspx]

-- reset workload
USE AdventureWorks2012
GO
SET NOCOUNT ON
GO
EXEC Demo.usp_DemoReset
GO


CREATE PROCEDURE dbo.usp_demo
WITH NATIVE_COMPILATION, EXECUTE AS OWNER, SCHEMABINDING
AS BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')


	SELECT p.Name, sop.SpecialOfferID 
	FROM Production.Product_inmem p JOIN Sales.SpecialOfferProduct_inmem sop ON p.ProductID=sop.ProductID


END
GO

EXEC dbo.usp_demo
GO

SET SHOWPLAN_XML ON
GO
EXEC dbo.usp_demo
GO
SET SHOWPLAN_XML OFF
GO


CREATE PROCEDURE dbo.usp_demo_interop
AS BEGIN


	SELECT p.Name, sop.SpecialOfferID 
	FROM Production.Product_inmem p JOIN Sales.SpecialOfferProduct_inmem sop ON p.ProductID=sop.ProductID


END
GO

SET SHOWPLAN_XML ON
GO
EXEC dbo.usp_demo_interop
GO
SET SHOWPLAN_XML OFF
GO


DROP PROC dbo.usp_demo
GO
DROP PROC dbo.usp_demo_interop
GO




SELECT p.ProductID, p.Name, p2.ProductID, p2.Name
FROM Production.Product_inmem p CROSS JOIN Production.Product_inmem  p2
GO
SET SHOWPLAN_XML ON
GO
SELECT p.ProductID, p.Name, p2.ProductID, p2.Name
FROM Production.Product_inmem p CROSS JOIN Production.Product_inmem  p2
GO
SET SHOWPLAN_XML OFF
GO
-- spot the plan differences


CREATE PROCEDURE dbo.usp_demo
WITH NATIVE_COMPILATION, EXECUTE AS OWNER, SCHEMABINDING
AS BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')


	SELECT p.ProductID, p.Name, p2.ProductID, p2.Name
	FROM Production.Product_inmem p CROSS JOIN Production.Product_inmem  p2


END
GO


EXEC dbo.usp_demo
GO

SET SHOWPLAN_XML ON
GO
EXEC dbo.usp_demo
GO
SET SHOWPLAN_XML OFF
GO
-- spot the plan differences


--clean up

DROP PROC dbo.usp_demo

-- ============================= end of native query demo
