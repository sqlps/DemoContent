-- 02 - Using Table Variables to generate a report

USE AdventureWorks2014
GO

--EXEC Track_TempDB..spr_Track_TempDB
--EXEC Track_TempDB..spi_Track_TempDB 'Start'

DECLARE @arg_CustomerID INT = 0
DECLARE @tmp_ErrorCount INT = 0

;WITH CTE_Customers (CustomerID, SalesCount) AS (
	SELECT TOP 10 CustomerId,COUNT(*) FROM Sales.SalesOrderHeader GROUP BY CustomerId ORDER BY COUNT(*) DESC
)
SELECT
	@arg_CustomerID = MIN(CustomerID)
FROM
	CTE_Customers 	

/* Declare a variable that references the type. */
DECLARE @Local_TVP AS SalesReport_Type ;

WHILE (@arg_CustomerID IS NOT NULL)
BEGIN

	/* Add data to the table variable. */
	INSERT @Local_TVP (
		 SalesOrderId	
		,OrderQty		
		,ProductID		
		,Name			
		,Class			
		,UnitPrice		
		,LineTotal		
	)
	SELECT
		 SOD.SalesOrderId
		,SOD.OrderQty
		,SOD.ProductID
		,P.Name
		,P.Class 
		,SOD.UnitPrice
		,SOD.LineTotal
	FROM
		Sales.SalesOrderHeader SOH 
		INNER JOIN Sales.SalesOrderDetail SOD 
			ON SOH.SalesOrderID = SOD.SalesOrderID
		INNER JOIN Production.Product P
			ON SOD.ProductID = P.ProductID
	WHERE
		CustomerID = @arg_CustomerID

	/* Pass the table variable data to a stored procedure. */
	EXEC usp_Rpt_SalesReport @arg_CustomerID , @Local_TVP ;

	/* DELETE */
	DELETE @Local_TVP

	;WITH CTE_Customers (CustomerID, SalesCount) AS (
		SELECT TOP 10 CustomerId,COUNT(*) FROM Sales.SalesOrderHeader GROUP BY CustomerId ORDER BY COUNT(*) DESC
	)
	SELECT
		@arg_CustomerID = MIN(CustomerID)
	FROM
		CTE_Customers 	
	WHERE
		CustomerID > @arg_CustomerID


END

--EXEC Track_TempDB..spi_Track_TempDB 'End'
