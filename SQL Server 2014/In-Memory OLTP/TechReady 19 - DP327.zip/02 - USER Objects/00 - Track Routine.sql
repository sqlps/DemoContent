/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- open this scrit and run it in parallel to capture everything that is going to TempDB and the in-memory usage
--		according to the SPs created on [01 - Setup]
--	1. the script will reset the contents on tracking tables (track_tempdb)
--	2. the script then runs a loop to check for an entry of type 'Start' 
--		it will wait for 5 miliseconds and check again
--  3. the script will run until it finds an entry of type 'end'
--		until it does not find an entry of type 'end' the script will run the code on spi_track_tempdb
--		every 5 miliseconds
--	4. once there is an entry of type 'End' the script will stop capturing tempdb / in-memory usage entries
--		and will run the report as specified with the parameters below


SET NOCOUNT ON
USE Track_TempDB
go
PRINT '******** RESETING CAPTURE ************'
exec Track_TempDB..spr_Track_TempDB
PRINT '******** WAITING FOR START ************'
WHILE (SELECT COUNT(*) FROM Track_TempDB..tdb_Control WHERE Run_Note = 'Start')=0
BEGIN
	waitfor delay '00:00:00:005'
END
PRINT '******** CAPTURING ************'
WHILE (SELECT COUNT(*) FROM Track_TempDB..tdb_Control WHERE Run_Note = 'End') =0
BEGIN
	exec Track_TempDB..spi_Track_TempDB 'auto'
	waitfor delay '00:00:00:010'
END
PRINT '******** REPORTING ************'
exec Track_TempDB..spl_Track_TempDB
 @skip_control = 0
,@skip_ObjectsCreated = 0
,@skip_PageAllocation = 0
,@skip_PerformanceCounters = 0
,@skip_Latches = 0
,@skip_Waits = 0
,@skip_UserObjects = 0
,@skip_XTPObjects  = 0
