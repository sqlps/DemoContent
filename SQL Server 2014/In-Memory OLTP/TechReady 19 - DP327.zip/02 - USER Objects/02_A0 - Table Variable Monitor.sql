/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

use tempdb
go
checkpoint
go

-- show TempDB TLOG entries
select 
	spid,[Current LSN],[Operation],[Context],[AllocUnitId],[AllocUnitName],[Page ID],[Slot ID],[Xact Type],[Transaction ID],[Transaction Name],[Description],[Begin Time],[End Time]
FROM 
	sys.fn_dblog(null, null)
go

-- show TempDB TLOG VLF contents
dbcc loginfo(2)

-- show USER objects in TempDB
select * 
from tempdb..sysobjects 
where type = 'U' order by crdate DESC

-- PAGES allocated to non SYSTEM OBJECTS
SELECT 
	allocated_page_file_id, 
	allocated_page_page_id, 
	* 
FROM 
	sys.dm_db_database_page_allocations(2, NULL , NULL, NULL, 'DETAILED')
WHERE 
	object_id not IN (SELECT ID from sysobjects WHERE type in ('S','IT','SQ'))
	and 
	Object_Id=	-1546580329

-- 'macro' statement to generate DBCC PAGE
SELECT --- *,
	'dbcc page( 2 , ' +
	rtrim(cast(allocated_page_file_id as char(3))) + ', ' +
	rtrim(cast(allocated_page_page_id as char(3))) + ', ' +
	' 3) -- ' +
	page_type_desc 
FROM 
	sys.dm_db_database_page_allocations(2, NULL , NULL, NULL, 'DETAILED')
WHERE 
	object_id not IN (SELECT ID from sysobjects WHERE type in ('S','IT','SQ'))
	and 
	Object_Id=	-1546580329
	and
	Page_Type=1

-- Enable TraceFlag 3604 to be able to see DBCC pages in SSMS result pane
dbcc traceon(3604)
go

-- allocated_page_file_id	allocated_page_page_id
-- Syntax: 
--	DBCC PAGE( DB-ID, FILE-ID , PAGE-ID , REPORT-STYLE) 
dbcc page( 2 , 1, 323,  3) -- IAM_PAGE
dbcc page( 2 , 1, 322,  3) -- DATA_PAGE
dbcc page( 2 , 1, 324,  3) -- DATA_PAGE