
/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- this script ....

USE AdventureWorks2014
GO


DECLARE @arg_TerritoryID INT = 0

DECLARE @Upper INT;
DECLARE @Lower INT
DECLARE @Rpt_Year INT = 2007
DECLARE @tmp_Year_Start DATETIME
DECLARE @tmp_Year_End DATETIME

SELECT 
	 @Lower = MIN(TerritoryID) ---- The lowest random number
	,@Upper = MAX(TerritoryID)
FROM 
	sales.SalesTerritory

SELECT
	 @tmp_Year_Start	= DATEFROMPARTS(@RPT_Year,01,01)
	,@tmp_Year_End		= DATEFROMPARTS(@RPT_Year,12,31)



SELECT @arg_TerritoryID = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
	
INSERT rpt_Sales_Report_Complex (
--	 Line_Number	
		session_id		
	,SalesOrderId	
	,SalesPersonID	
	,OrderQty		
	,ProductID		
	,Name			
	,Class			
	,UnitPrice		
	,LineTotal		
)		
SELECT
		@@SPID -- session_id
	,SOD.SalesOrderId
	,ISNULL(SalesPersonID	, -1)
	,SOD.OrderQty
	,SOD.ProductID
	,P.Name
	,P.Class 
	,SOD.UnitPrice
	,SOD.LineTotal
FROM
	Sales.SalesOrderHeader SOH 
	INNER JOIN Sales.SalesOrderDetail SOD 
		ON SOH.SalesOrderID = SOD.SalesOrderID
	INNER JOIN Production.Product P
		ON SOD.ProductID = P.ProductID
WHERE
		TerritoryID = @arg_TerritoryID
		AND
		ShipDate >= @tmp_Year_Start 
		AND
		ShipDate <= @tmp_Year_End


INSERT rpt_Sales_Report_Summary_Complex (
		session_id		
	,SalesPersonID	
	,Sum_LineTotal	
	,Pct_LineTotal	
)
SELECT
		@@SPID
	,SalesPersonID	
	,SUM(LineTotal) 
	,0.0000
FROM
	rpt_Sales_Report_Complex
WHERE
	session_id = @@SPID
GROUP BY 
		SalesPersonID	

DECLARE @RPT_Total MONEY = 0.0000
SELECT 
	@RPT_Total = SUM(Sum_LineTotal)
FROM
	rpt_Sales_Report_Summary_Complex
WHERE
	session_id = @@SPID

UPDATE 
	rpt_Sales_Report_Summary_Complex
SET
	Pct_LineTotal = Sum_LineTotal / @RPT_Total * 100.0000
WHERE
	session_id = @@SPID


SELECT 
		@arg_TerritoryID AS TerritoryID
	,*
FROM
	rpt_Sales_Report_Summary_Complex
WHERE
	session_id = @@SPID


-- CLEAN-UP
DELETE FROM 
	rpt_Sales_Report_Complex	
WHERE 
	session_id = @@SPID


DELETE FROM 
	rpt_Sales_Report_Summary_Complex
WHERE 
	session_id = @@SPID

