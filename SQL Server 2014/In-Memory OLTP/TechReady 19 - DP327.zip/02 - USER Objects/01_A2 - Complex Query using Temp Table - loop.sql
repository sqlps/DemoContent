/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- this is the report that uses 2 TempDB user objects to simulate a little bit more complex usage of TempDB
-- 

USE AdventureWorks2014
GO

DECLARE @arg_TerritoryID INT = 0

DECLARE @Upper INT;
DECLARE @Lower INT
DECLARE @Rpt_Year INT = 2007
DECLARE @tmp_Year_Start DATETIME
DECLARE @tmp_Year_End DATETIME

SELECT 
	 @Lower = MIN(TerritoryID) ---- The lowest random number
	,@Upper = MAX(TerritoryID)
FROM 
	sales.SalesTerritory

SELECT
	 @tmp_Year_Start	= DATEFROMPARTS(@RPT_Year,01,01)
	,@tmp_Year_End		= DATEFROMPARTS(@RPT_Year,12,31)

	SELECT @arg_TerritoryID = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)

	-- sp_help 'Sales.SalesOrderDetail'
	-- sp_help 'Production.Product'
	CREATE TABLE #sales_report (
		 SalesOrderId	INT NOT NULL
		,SalesPersonID	INT NOT NULL
		,OrderQty		SMALLINT NOT NULL
		,ProductID		INT NOT NULL
		,Name			CHAR(100) NOT NULL
		,Class			NCHAR(4) NULL
		,UnitPrice		MONEY	NOT NULL
		,LineTotal		MONEY	NOT NULL
	)
	-- select * from sys.systypes order by name
	INSERT #sales_report (
		 SalesOrderId	
		,SalesPersonID	
		,OrderQty		
		,ProductID		
		,Name			
		,Class			
		,UnitPrice		
		,LineTotal		
	)
	SELECT
		 SOD.SalesOrderId
		,ISNULL(SalesPersonID	, -1)
		,SOD.OrderQty
		,SOD.ProductID
		,P.Name
		,P.Class 
		,SOD.UnitPrice
		,SOD.LineTotal
	FROM
		Sales.SalesOrderHeader SOH 
		INNER JOIN Sales.SalesOrderDetail SOD 
			ON SOH.SalesOrderID = SOD.SalesOrderID
		INNER JOIN Production.Product P
			ON SOD.ProductID = P.ProductID
	WHERE
			TerritoryID = @arg_TerritoryID
			AND
			ShipDate >= @tmp_Year_Start 
			AND
			ShipDate <= @tmp_Year_End

	;WITH CTE_Sales_By_SalesPersonID (SalesPersonID, SUM_Sales) AS
	(
		SELECT
			 SalesPersonID	
			,SUM(LineTotal) 
		FROM
			#sales_report
		GROUP BY 
			 SalesPersonID	
	)
	SELECT
		 @arg_TerritoryID as TerritoryID
		,CASE SalesPersonID
			WHEN -1 THEN NULL
			ELSE SalesPersonID
		 END AS SalesPersonID
		,SUM_Sales
		,SUM_Sales / (SUM(SUM_Sales) OVER()) * 100.0000
	FROM
		CTE_Sales_By_SalesPersonID


	DROP TABLE #sales_report
