/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

USE AdventureWorks2014;
GO

/* Create a table type. */
DROP table rpt_Sales_Report
GO
create table rpt_Sales_Report (
	 Line_Number	INT IDENTITY (1,1) NOT NULL primary key nonclustered hash (Line_Number) with (bucket_count = 10000000) 
	,session_id		INT NOT NULL
	,SalesOrderId	INT NOT NULL
	,OrderQty		SMALLINT NOT NULL
	,ProductID		INT NOT NULL
	,Name			CHAR(100) NOT NULL
	,Class			NCHAR(4) NULL
	,UnitPrice		MONEY	NOT NULL
	,LineTotal		MONEY	NOT NULL
	INDEX ix_rpt_Sales_Report_session NONCLUSTERED (session_id)
)
with 
	(
		 memory_optimized = on 
		,Durability = SCHEMA_ONLY
	)  



/* Create a procedure to receive data for the table-valued parameter. */
DROP PROCEDURE dbo.usp_Rpt_SalesReport_2
GO
CREATE PROCEDURE dbo.usp_Rpt_SalesReport_2
	 @arg_Customer INT
    ,@arg_session_id INT
AS 
SET NOCOUNT ON
SELECT 
	 @@SPID
	,@arg_Customer
	,*
FROM  
	AdventureWorks2014..rpt_Sales_Report
WHERE
	session_id = @arg_session_id
GO

/* local variables */
DECLARE @arg_CustomerID INT = 0

DECLARE @Upper INT;
DECLARE @Lower INT
DECLARE @Rpt_Counter INT = 0;

SELECT 
	 @Lower = 11000
	,@Upper = 30118

SELECT @arg_CustomerID = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)


/* Add data to the table variable. */
INSERT AdventureWorks2014..rpt_Sales_Report (
	 session_id
	,SalesOrderId	
	,OrderQty		
	,ProductID		
	,Name			
	,Class			
	,UnitPrice		
	,LineTotal		
)
SELECT
	 @@SPID
	,SOD.SalesOrderId
	,SOD.OrderQty
	,SOD.ProductID
	,P.Name
	,P.Class 
	,SOD.UnitPrice
	,SOD.LineTotal
FROM
	Sales.SalesOrderHeader SOH 
	INNER JOIN Sales.SalesOrderDetail SOD 
		ON SOH.SalesOrderID = SOD.SalesOrderID
	INNER JOIN Production.Product P
		ON SOD.ProductID = P.ProductID
WHERE
	CustomerID = @arg_CustomerID

/* Pass the table variable data to a stored procedure. */
--EXEC usp_Rpt_SalesReport_2 @arg_CustomerID , @@SPID ;
SELECT @arg_CustomerID , @@SPID , *
FROM AdventureWorks2014..rpt_Sales_Report
WHERE 
	session_id = @@SPID;

DELETE AdventureWorks2014..rpt_Sales_Report
WHERE 
	session_id = @@SPID

