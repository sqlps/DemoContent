/*
select * from sales.SalesTerritory

select * from sales.SalesOrderHeader order by YEAR(ShipDate),TerritoryID

-- orders by year/Territory
select COUNT(*),YEAR(ShipDate),TerritoryID 
from sales.SalesOrderHeader 
GROUP by YEAR(ShipDate),TerritoryID
ORDER by YEAR(ShipDate),TerritoryID

-- orders by year
select COUNT(*),YEAR(ShipDate)
from sales.SalesOrderHeader 
GROUP by YEAR(ShipDate)
ORDER by YEAR(ShipDate)

*/


DECLARE @arg_TerritoryID INT = 0

DECLARE @Upper INT;
DECLARE @Lower INT
DECLARE @Rpt_Year INT = 2007
DECLARE @tmp_Year_Start DATETIME
DECLARE @tmp_Year_End DATETIME

SELECT 
	 @Lower = MIN(TerritoryID) ---- The lowest random number
	,@Upper = MAX(TerritoryID)
FROM 
	sales.SalesTerritory

SELECT @arg_TerritoryID = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)

SELECT
	 @tmp_Year_Start	= DATEFROMPARTS(@RPT_Year,01,01)
	,@tmp_Year_End		= DATEFROMPARTS(@RPT_Year,12,31)


-- sp_help 'Sales.SalesOrderDetail'
-- sp_help 'Production.Product'
BEGIN TRY
	DROP TABLE #sales_report
END TRY
BEGIN CATCH
	PRINT 'Temp table #sales_report does not exist. Code will proceed'
END CATCH
CREATE TABLE #sales_report (
	 SalesOrderId	INT NOT NULL
	,SalesPersonID	INT NOT NULL
	,OrderQty		SMALLINT NOT NULL
	,ProductID		INT NOT NULL
	,Name			CHAR(100) NOT NULL
	,Class			NCHAR(4) NULL
	,UnitPrice		MONEY	NOT NULL
	,LineTotal		MONEY	NOT NULL
)
-- select * from sys.systypes order by name
INSERT #sales_report (
	 SalesOrderId	
	,SalesPersonID	
	,OrderQty		
	,ProductID		
	,Name			
	,Class			
	,UnitPrice		
	,LineTotal		
)
SELECT
	 SOD.SalesOrderId
	,ISNULL(SalesPersonID	, -1)
	,SOD.OrderQty
	,SOD.ProductID
	,P.Name
	,P.Class 
	,SOD.UnitPrice
	,SOD.LineTotal
FROM
	Sales.SalesOrderHeader SOH 
	INNER JOIN Sales.SalesOrderDetail SOD 
		ON SOH.SalesOrderID = SOD.SalesOrderID
	INNER JOIN Production.Product P
		ON SOD.ProductID = P.ProductID
WHERE
		TerritoryID = @arg_TerritoryID
		AND
		ShipDate >= @tmp_Year_Start 
		AND
		ShipDate <= @tmp_Year_End

;WITH CTE_Sales_By_SalesPersonID (SalesPersonID, SUM_Sales) AS
(
	SELECT
		 SalesPersonID	
		,SUM(LineTotal) 
	FROM
		#sales_report
	GROUP BY 
		 SalesPersonID	
)
SELECT
	 @arg_TerritoryID as TerritoryID
	,CASE SalesPersonID
		WHEN -1 THEN NULL
		ELSE SalesPersonID
	 END AS SalesPersonID
	,SUM_Sales
	,SUM_Sales / (SUM(SUM_Sales) OVER()) * 100.0000
FROM
	CTE_Sales_By_SalesPersonID


DROP TABLE #sales_report