/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

----------------------------------------------------------------------------------------------------------------------------------
-- REFERENCES:																													--
-- http://msdn.microsoft.com/en-us/library/ms176029.aspx																		--
-- Monitor and Troubleshoot Memory Usage: http://msdn.microsoft.com/en-us/library/dn465869.aspx									--
--	Transact-SQL Constructs Not Supported by In-Memory OLTP: http://msdn.microsoft.com/en-us/library/dn246937(v=sql.120).aspx	-- 
--	Implementing IDENTITY in a Memory-Optimized Table: http://msdn.microsoft.com/en-us/library/dn247640.aspx					--
----------------------------------------------------------------------------------------------------------------------------------

USE [master]
GO
if DB_ID('Track_TempDB') is not null
	drop database Track_TempDB
GO
CREATE DATABASE Track_TempDB
    ON 
    PRIMARY(NAME = [Track_TempDB_hk_fs_data], 
			FILENAME = 'd:\Program Files\Microsoft SQL Server 2014\MSSQL12.INST_2014_A\MSSQL\DATA\Track_TempDB_hk_fs_data.mdf', size=500MB), 
    FILEGROUP [Track_TempDB_hk_fs_fg] CONTAINS MEMORY_OPTIMIZED_DATA(
			NAME = [Track_TempDB_hk_fs_dir], 
			FILENAME = 'd:\Program Files\Microsoft SQL Server 2014\MSSQL12.INST_2014_A\MSSQL\DATA\Track_TempDB_hk_fs_dir') 
	LOG ON (
		name = [Track_TempDB_log], 
		FILENAME = 'd:\Program Files\Microsoft SQL Server 2014\MSSQL12.INST_2014_A\MSSQL\LOG\Track_TempDB_hk_fs_log.ldf', size=500MB)
	COLLATE Latin1_General_100_BIN2;
GO

USE Track_TempDB
GO
DROP TABLE tdb_Control
GO
CREATE TABLE tdb_Control
(
	 Run_Number	INT IDENTITY(1,1) NOT NULL primary key nonclustered (Run_Number) 
	,Run_Datetime DATETIME NOT NULL DEFAULT GETDATE()
	,Run_Note Varchar(30) NULL DEFAULT 'Agent'
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  

GO

DROP table tdb_usage 
GO
create table tdb_usage (
	 Run_Number INT NOT NULL primary key nonclustered (Run_Number,session_id) 
	,task_address	varbinary	(8) NULL
	,is_remote_task	bit	NOT NULL
	,session_id	smallint	NOT NULL
	,request_id	int	NULL
	,exec_context_id	int	NULL
	,database_id	int	NULL
	,user_objects_alloc_page_count	bigint	NULL
	,user_objects_dealloc_page_count	bigint	NULL
	,internal_objects_alloc_page_count	bigint	NULL
	,internal_objects_dealloc_page_count	bigint	NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  


DROP TABLE tdb_PageAllocation 
GO
create table tdb_PageAllocation (
	 Run_Number INT NOT NULL primary key nonclustered (Run_Number, file_id , filegroup_id) 
	,file_id smallint NOT NULL
	,filegroup_id smallint  NOT NULL
	,total_page_count BIGINT NULL
	,allocated_extent_page_count  BIGINT NULL
	,unallocated_extent_page_count BIGINT NULL
	,version_store_reserved_page_count BIGINT NULL
	,user_object_reserved_page_count BIGINT NULL
	,internal_object_reserved_page_count BIGINT NULL
	,mixed_extent_page_count BIGINT NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
GO

DROP TABLE tdb_AllocationByTask
GO
CREATE TABLE tdb_AllocationByTask
(
	 Run_Number INT NOT NULL primary key nonclustered (Run_Number, session_id) 
	,task_address binary(8) NOT NULL
	,is_remote_task smallint not null
	,session_id smallint NOT NULL
	,request_id int NOT NULL
	,exec_context_id int NOT NULL
	,database_id smallint NOT NULL
	,user_objects_alloc_page_count bigint NOT NULL
	,user_objects_dealloc_page_count bigint NOT NULL
	,internal_objects_alloc_page_count bigint NOT NULL
	,internal_objects_dealloc_page_count bigint NOT NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
go

DROP TABLE tdb_PagesAllocDeallocBySession
GO
CREATE TABLE tdb_PagesAllocDeallocBySession (
	 Run_Number INT NOT NULL  primary key nonclustered (Run_Number, session_id) 
	,session_id smallint  NOT NULL
	,database_id smallint NOT NULL
	,user_objects_alloc_page_count bigint NOT NULL
	,user_objects_dealloc_page_count bigint NOT NULL
	,internal_objects_alloc_page_count bigint NOT NULL
	,internal_objects_dealloc_page_count bigint NOT NULL
 )
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
go

DROP TABLE tdb_ExecSession
GO
CREATE TABLE tdb_ExecSession (
	 Run_Number INT NOT NULL  primary key nonclustered (Run_Number, session_id) 
	,session_id smallint NOT NULL
	,login_time datetime NOT NULL
	,host_name nvarchar(128)  NULL
	,program_name nvarchar(128) NULL
	,host_process_id int NULL
	,client_version int NULL
	,client_interface_name nvarchar(32) NULL
	,security_id varbinary(85)  NOT NULL
	,login_name nvarchar(128)  NOT NULL
	,nt_domain nvarchar(128)  NULL
	,nt_user_name nvarchar(128) NULL
	,status nvarchar(30) NOT NULL
	,context_info varbinary(128) NULL
	,cpu_time int NOT NULL 
	,memory_usage int NOT NULL
	,total_scheduled_time int NOT NULL
	,total_elapsed_time int NOT NULL
	,endpoint_id int NOT NULL
	,last_request_start_time datetime NOT NULL
	,last_request_end_time datetime NULL
	,reads bigint NOT NULL
	,writes bigint NOT NULL
	,logical_reads bigint NOT NULL
	,is_user_process bit NOT NULL
	,text_size int NOT NULL
	,language nvarchar(128) NULL
	,date_format nvarchar(3) NULL
	,date_first smallint  NOT NULL
	,quoted_identifier bit NOT NULL
	,arithabort bit NOT NULL
	,ansi_null_dflt_on bit NOT NULL
	,ansi_defaults bit NOT NULL
	,ansi_warnings bit NOT NULL
	,ansi_padding bit NOT NULL
	,ansi_nulls bit NOT NULL
	,concat_null_yields_null bit NOT NULL
	,transaction_isolation_level smallint NOT NULL
	,lock_timeout int NOT NULL
	,deadlock_priority int NOT NULL
	,row_count bigint NOT NULL
	,prev_error int NOT NULL
	,original_security_id varbinary(85) NOT NULL
	,original_login_name nvarchar(128) NOT NULL
	,last_successful_logon datetime  NULL
	,last_unsuccessful_logon datetime NULL
	,unsuccessful_logons bigint NULL
	,group_id int NOT NULL
	,authenticating_database_id int NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
go

DROP TABLE tdb_ExecRequests
GO
CREATE TABLE tdb_ExecRequests (
	 Run_Number INT NOT NULL  primary key nonclustered (Run_Number, session_id , request_id) 
	,session_id smallint NOT NULL
	,request_id int NOT NULL
	,start_time datetime NOT NULL
	,status nvarchar(30) NOT NULL
	,command nvarchar(32) NOT NULL
	,sql_handle varbinary(64) NULL
	,statement_start_offset int NULL
	,statement_end_offset int NULL
	,plan_handle varbinary(64) NULL
	,database_id smallint NOT NULL
	,user_id int NOT NULL
	,connection_id uniqueidentifier NULL
	,blocking_session_id smallint NULL
	,wait_type nvarchar(60) NULL
	,wait_time int NOT NULL
	,last_wait_type nvarchar(60) NOT NULL
	,wait_resource nvarchar(256) NOT NULL
	,open_transaction_count int NOT NULL
	,open_resultset_count int NOT NULL
	,transaction_id bigint NOT NULL
	,context_info varbinary(128) NULL
	,percent_complete real NOT NULL 
	,estimated_completion_time  bigint NOT NULL
	,cpu_time int NOT NULL
	,total_elapsed_time int NOT NULL
	,scheduler_id int NULL
	,task_address varbinary(8) null
	,reads bigint NOT NULL
	,writes bigint NOT NULL
	,logical_reads bigint NOT NULL
	,text_size int NOT NULL
	,language nvarchar(128) NULL
	,date_format nvarchar(3) NULL
	,date_first smallint  NOT NULL
	,quoted_identifier bit NOT NULL
	,arithabort bit  NOT NULL
	,ansi_null_dflt_on bit NOT NULL
	,ansi_defaults bit NOT NULL
	,ansi_warnings bit NOT NULL
	,ansi_padding bit NOT NULL
	,ansi_nulls bit NOT NULL
	,concat_null_yields_null bit NOT NULL
	,transaction_isolation_level smallint NOT NULL
	,lock_timeout int NOT NULL
	,deadlock_priority int NOT NULL
	,row_count bigint NOT NULL
	,prev_error int NOT NULL
	,nest_level int NOT NULL
	,granted_query_memory int NOT NULL
	,executing_managed_code bit NOT NULL
	,group_id int  NOT NULL
	,query_hash binary(8) NULL
	,query_plan_hash binary(8) NULL
) 
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
go

DROP TABLE tdb_SysObjects
GO
CREATE TABLE tdb_SysObjects (
 	 Run_Number INT NOT NULL  primary key nonclustered (Run_Number, object_id) 
	,name sysname NOT NULL
	,object_id int NOT NULL
	,principal_id int NULL
	,schema_id int  NULL
	,parent_object_id int NULL
	,type char(2) NOT NULL
	,type_desc nvarchar(60) NOT NULL
	,create_date datetime NOT NULL
	,modify_date  datetime NULL
	,is_ms_shipped bit NOT NULL
	,is_published bit NOT NULL
	,is_schema_published bit NOT NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
go

DROP TABLE tdb_PerformanceCounters
GO
CREATE TABLE tdb_PerformanceCounters
(
 	 Run_Number INT NOT NULL  primary key nonclustered (Run_Number ,object_name,counter_name,instance_name  ) 
	,object_name nchar(128) NOT NULL
	,counter_name nchar(128) NOT NULL
	,instance_name nchar(128) NOT NULL
	,cntr_value bigint NOT NULL
	,cntr_type int NOT NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  

DROP TABLE tdb_ReadsWrites
GO
CREATE TABLE tdb_ReadsWrites
(
 	 Run_Number INT NOT NULL  primary key nonclustered (Run_Number ,database_id ,file_id) 
	,database_id smallint NOT NULL
	,file_id smallint NOT NULL
	,sample_ms int NOT NULL
	,num_of_reads bigint NOT NULL
	,num_of_bytes_read bigint NOT NULL
	,io_stall_read_ms bigint NOT NULL
	,num_of_writes bigint NOT NULL
	,num_of_bytes_written bigint NOT NULL
	,io_stall_write_ms bigint NOT NULL
	,io_stall bigint NOT NULL
	,size_on_disk_bytes bigint NOT NULL
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  


----------------------------------- 
DROP TABLE [dbo].[tdb_sysprocesses]
GO
CREATE TABLE [dbo].[tdb_sysprocesses](
	Run_Number INT NOT NULL  primary key nonclustered (Run_Number ,spid) ,
	[spid] [smallint] NOT NULL,
	[kpid] [smallint] NOT NULL,
	[blocked] [smallint] NOT NULL,
	[waittype] [binary](2) NOT NULL,
	[waittime] [bigint] NOT NULL,
	[lastwaittype] [nchar](32) NOT NULL,
	[waitresource] [nchar](256) NOT NULL,
	[dbid] [smallint] NOT NULL,
	[uid] [smallint] NULL,
	[cpu] [int] NOT NULL,
	[physical_io] [bigint] NOT NULL,
	[memusage] [int] NOT NULL,
	[login_time] [datetime] NOT NULL,
	[last_batch] [datetime] NOT NULL,
	[ecid] [smallint] NOT NULL,
	[open_tran] [smallint] NOT NULL,
	[status] [nchar](30) NOT NULL,
	[sid] [binary](86) NOT NULL,
	[hostname] [nchar](128) NOT NULL,
	[program_name] [nchar](128) NOT NULL,
	[hostprocess] [nchar](10) NOT NULL,
	[cmd] [nchar](16) NOT NULL,
	[nt_domain] [nchar](128) NOT NULL,
	[nt_username] [nchar](128) NOT NULL,
	[net_address] [nchar](12) NOT NULL,
	[net_library] [nchar](12) NOT NULL,
	[loginame] [nchar](128) NOT NULL,
	[context_info] [binary](128) NOT NULL,
	[sql_handle] [binary](20) NOT NULL,
	[stmt_start] [int] NOT NULL,
	[stmt_end] [int] NOT NULL,
	[request_id] [int] NOT NULL
) --ON [PRIMARY]
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
GO

DROP TABLE [dbo].[tdb_waiting_tasks]
GO
CREATE TABLE [dbo].[tdb_waiting_tasks](
	Run_Number INT NOT NULL  primary key nonclustered (Run_Number ,session_id, wait_type) ,
	[session_id] [smallint] NOT NULL,
	[wait_type] [nvarchar](60) NOT NULL,
	[wait_duration_ms] [bigint] NULL,
	[resource_description] [nvarchar](3072) NULL
) 
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  


DROP TABLE [dbo].[xtp_table_memory_stats]
GO
CREATE TABLE [dbo].[xtp_table_memory_stats] (
	 Run_Number							INT NOT NULL primary key nonclustered (Run_Number , database_id , object_id) 
	,database_id						INT NOT NULL
	,database_name						sysname NULL
	,object_name						sysname	NULL
	,object_id							int  NOT NULL -- The object ID of the table. NULL for In-Memory OLTP system tables.
	,memory_allocated_for_table_kb		bigint   -- Memory allocated for this table.
	,memory_used_by_table_kb			bigint   -- Memory used by table, including row versions.
	,memory_allocated_for_indexes_kb	bigint	 -- Memory allocated for indexes on this table.
	,memory_used_by_indexes_kb			bigint   -- Memory consumed for indexes on this table.
)
with (
	 MEMORY_OPTIMIZED = OFF
)  

DROP TABLE [dbo].[xtp_resource_governor_resource_pools]
GO
CREATE TABLE [dbo].[xtp_resource_governor_resource_pools] (
	 Run_Number							INT NOT NULL primary key nonclustered (Run_Number ,pool_id) 
	,pool_id	int	NOT NULL-- The ID of the resource pool. Is not nullable.
	,name	sysname	-- The name of the resource pool. Is not nullable.
	,statistics_start_time	datetime	-- The time when statistics was reset for this pool. Is not nullable.
	,total_cpu_usage_ms	bigint	-- The cumulative CPU usage in milliseconds since the Resource Govenor statistics were reset. Is not nullable.
	,cache_memory_kb	bigint	-- The current total cache memory usage in kilobytes. Is not nullable.
	,compile_memory_kb	bigint	-- The current total stolen memory usage in kilobytes (KB). The majority of this usage would be for compile and optimization, but it can also include other memory users. Is not nullable.
	,used_memgrant_kb	bigint	-- The current total used (stolen) memory from memory grants. Is not nullable.
	,total_memgrant_count	bigint	-- The cumulative count of memory grants in this resource pool. Is not nullable.
	,total_memgrant_timeout_count	bigint	-- The cumulative count of memory grant time-outs in this resource pool. Is not nullable.
	,active_memgrant_count	int	-- The current count of memory grants. Is not nullable.
	,active_memgrant_kb	bigint	-- The sum, in kilobytes (KB), of current memory grants. Is not nullable.
	,memgrant_waiter_count	int	-- The count of queries currently pending on memory grants. Is not nullable.
	,max_memory_kb	bigint	-- The maximum amount of memory, in kilobytes, that the resource pool can have. This is based on the current settings and server state. Is not nullable.
	,used_memory_kb	bigint	--The amount of memory used, in kilobytes, for the resource pool. Is not nullable.
	,target_memory_kb	bigint	--The target amount of memory, in kilobytes, the resource pool is trying to attain. This is based on the current settings and server state. Is not nullable.
	,out_of_memory_count	bigint	--The number of failed memory allocations in the pool since the Resource Govenor statistics were reset. Is not nullable.
	,min_cpu_percent	int	--The current configuration for the guaranteed average CPU bandwidth for all requests in the resource pool when there is CPU contention. Is not nullable.
	,max_cpu_percent	int	--The current configuration for the maximum average CPU bandwidth allowed for all requests in the resource pool when there is CPU contention. Is not nullable.
	,min_memory_percent	int	--The current configuration for the guaranteed amount of memory for all requests in the resource pool when there is memory contention. This is not shared with other resource pools. Is not nullable.
	,max_memory_percent	int	--The current configuration for the percentage of total server memory that can be used by requests in this resource pool. Is not nullable.
	,cap_cpu_percent	int	--Hard cap on the CPU bandwidth that all requests in the resource pool will receive. Limits the maximum CPU bandwidth level to the specified level. The allowed range for value is from 1 through 100. Is not nullable.
	,min_iops_per_volume	int	--The minimum IO per second (IOPS) per disk volume setting for this Pool. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0.
	,max_iops_per_volume	int	--The maximum IO per second (IOPS) per disk volume setting for this Pool. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0..
	,read_io_queued_total	int	--The total read IOs enqueued since the Resource Govenor was reset. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0.
	,read_io_issued_total	int	--The total read IOs issued since the Resource Govenor statistics were reset. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0.
	,read_io_completed_total	int	--The total read IOs completed since the Resource Govenor statistics were reset. Is not nullable.
	,read_io_throttled_total	int	--The total read IOs throttled since the Resource Govenor statistics were reset. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0.
	,read_bytes_total	bigint	-- The total number of bytes read since the Resource Govenor statistics were reset. Is not nullable.
	,read_io_stall_total_ms	bigint	-- Total time (in milliseconds) between read IO issue and completion. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0.
	,read_io_stall_queued_ms	bigint	-- Total time (in milliseconds) between read IO arrival and completion. Is nullable. Null if the resource pool is not governed for IO. That is, the Resource Pool MIN_IOPS_PER_VOLUME and MAX_IOPS_PER_VOLUME settings are 0.
									-- To determine if the IO setting for the pool is causing latency, subtract read_io_stall_queued_ms from read_io_stall_total_ms.
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  

DROP TABLE [dbo].[xtp_system_memory_consumers]
GO
CREATE TABLE [dbo].[xtp_system_memory_consumers] (
	 Run_Number							INT NOT NULL primary key nonclustered (Run_Number ,memory_consumer_id ) 
	,memory_consumer_id		bigint NOT NULL -- Internal ID for memory consumer.
	,memory_consumer_type	int			-- An integer that represents the type of the memory consumer.
										-- 0 � It should not be displayed.
										--		Aggregates memory usage of two or more consumers.

										-- 1 � LOOKASIDE
										--		Tracks memory consumption for a system lookaside.

										-- 2 - VARHEAP
										--		Tracks memory consumption for a variable-length heap.
										-- 4 - IO page pool
										--		Tracks memory consumption for a system page pool used for IO operations.
	,memory_consumer_type_desc	nvarchar(64)	-- The description of the type of memory consumer:
												-- 0 � It should not be displayed.
												-- 1 � LOOKASIDE
												-- 2 - VARHEAP
												-- 4 - PGPOOL
	,memory_consumer_desc		nvarchar(64)	-- Description of the memory consumer instance:
												-- VARHEAP
												--		System heap. General purpose. Currently only used to allocate garbage collection work items.
												--		Lookaside heap. Used by looksides when the number of items contained in the lookaside list reaches a predetermined cap (usually around 5,000 items).
												-- PGPOOL
												--		For IO system pools there are three different sizes System 4K page pool, System 64K page pool, and System 256K page pool.
--	,lookaside_id				bigint			-- The ID of the thread-local, lookaside memory provider.
	,pagepool_id				bigint			-- The ID of the thread-local, page pool memory provider.
	,allocated_bytes			bigint			-- Number of bytes reserved for this consumer.
	,used_bytes					bigint			-- Bytes used by this consumer. Applies only to varheap memory consumers.
	,allocation_count			int				-- Number of allocations.
	,partition_count			int				-- Internal use only.
--	,sizeclass_count			int				-- Internal use only.
--	,min_sizeclass				int				-- Internal use only.
--	,max_sizeclass				int				-- Internal use only.
--	,memory_consumer_address	varbinary		-- Internal address of the consumer.
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  



DROP TABLE [dbo].[xtp_memory_clerks]
GO
CREATE TABLE [dbo].[xtp_memory_clerks] (
	 Run_Number			INT NOT NULL primary key nonclustered (Run_Number , name , memory_node_id ) 
	,name				nvarchar(256) NOT NULL --
	,memory_node_id		smallint  NOT NULL
	,pages_kb			bigint 
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
  

DROP TABLE [dbo].[xtp_hash_index_stats]
GO
CREATE TABLE [dbo].[xtp_hash_index_stats] (
	 Run_Number			INT NOT NULL primary key nonclustered (Run_Number , database_id, object_id , index_id ) 
	,database_id		INT NOT NULL
	,database_name		nvarchar(256) NOT NULL --
	,object_id			INT NOT NULL --
	,object_name		nvarchar(256) NOT NULL --
	,index_id			INT NOT NULL
	,index_name			nvarchar(256) NOT NULL --
	,total_bucket_count	INT NOT NULL
	,empty_bucket_count	INT NOT NULL
	,avg_chain_length	INT	NOT NULL
	,max_chain_length	INT	NOT NULL
	,row_count			INT NOT NULL
	,distinct_keys		INT NOT NULL
)


DROP TABLE [dbo].[xtp_index_stats]
GO
CREATE TABLE [dbo].[xtp_index_stats] (
	 Run_Number				INT NOT NULL primary key nonclustered (Run_Number , database_id , object_id , index_id ) 
	,database_id			INT NOT NULL
	,database_name			nvarchar(256) NOT NULL --
	,object_id				INT NOT NULL --
	,object_name			nvarchar(256) NOT NULL --
	,index_id				INT NOT NULL
	,index_name				nvarchar(256) NOT NULL --
	,scans_started			INT NOT NULL
	,scans_retries			INT NOT NULL
	,rows_returned			INT NOT NULL
	,rows_touched			INT NOT NULL
	,rows_expiring			INT NOT NULL
	,rows_expired			INT NOT NULL
	,rows_expired_removed	INT NOT NULL
	,usage_pattern		varchar(10) NULL
)
with (
	 MEMORY_OPTIMIZED = OFF
)  


USE Track_TempDB
GO
DROP TABLE [dbo].[xtp_checkpoint_files]
GO
CREATE TABLE [dbo].[xtp_checkpoint_files] (
	 Run_Number						INT			NOT NULL primary key nonclustered (Run_Number , db_id , internal_storage_slot) 
	,db_id							INT			NOT NULL
	,internal_storage_slot			int			NOT NULL
	,file_size_MB					int			NULL
	,file_size_used_MB				int			NULL
	,inserted_row_count				bigint		NULL
	,deleted_row_count				bigint		NULL
	,data_delta_file_pairs			smallint	NULL
	,percent_full					decimal(10,4) NULL
)


USE Track_TempDB
GO
DROP TABLE [dbo].[xtp_object_stats]
GO
CREATE TABLE [dbo].[xtp_object_stats] (
	 Run_Number				INT NOT NULL primary key nonclustered (Run_Number ,database_id	, object_id) 
	,database_id			INT NOT NULL 
	,object_id				INT NOT NULL --
	,object_name			nvarchar(256) NOT NULL --
	,row_insert_attempts	INT NOT NULL 
	,row_update_attempts	INT NOT NULL 
	,row_delete_attempts	INT NOT NULL 
	,write_conflicts		INT NOT NULL 
)


/*
use master
go
BACKUP DATABASE [Track_TempDB] TO  DISK = N'd:\Program Files\Microsoft SQL Server 2014\MSSQL12.INST_2014_A\MSSQL\Backup\Track_TempDB.bak' WITH NOFORMAT, NOINIT,  NAME = N'Track_TempDB-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
*/
/*
USE [master]
BACKUP LOG [Track_TempDB] TO  DISK = N'd:\Program Files\Microsoft SQL Server 2014\MSSQL12.INST_2014_A\MSSQL\Backup\Track_TempDB_LogBackup_2014-07-24_15-48-50.bak' WITH NOFORMAT, NOINIT,  NAME = N'Track_TempDB_LogBackup_2014-07-24_15-48-50', NOSKIP, NOREWIND, NOUNLOAD,  NORECOVERY ,  STATS = 5
RESTORE DATABASE [Track_TempDB] FROM  DISK = N'd:\Program Files\Microsoft SQL Server 2014\MSSQL12.INST_2014_A\MSSQL\Backup\Track_TempDB.bak' WITH  FILE = 1,  NOUNLOAD,  STATS = 5
GO
*/
