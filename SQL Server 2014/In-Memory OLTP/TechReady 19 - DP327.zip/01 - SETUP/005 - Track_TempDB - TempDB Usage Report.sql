/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

/*
	REFERENCES:
	-- http://msdn.microsoft.com/en-us/library/dn133081.aspx
	-- http://msdn.microsoft.com/en-us/library/dn133191.aspx
	-- http://blogs.technet.com/b/dataplatforminsider/archive/2014/01/30/in-memory-oltp-index-troubleshooting-part-ii.aspx

	-- total storage used by in-memory tables: http://msdn.microsoft.com/en-us/library/dn133201.aspx
	*/


*/




USE Track_TempDB
GO

DROP PROCEDURE spl_Track_TempDB 
GO
CREATE PROCEDURE spl_Track_TempDB
 @skip_control tinyint = 0
,@skip_ObjectsCreated tinyint = 0
,@skip_PageAllocation tinyint = 0
,@skip_PerformanceCounters tinyint = 0
,@skip_Latches tinyint = 0
,@skip_Waits tinyint = 0
,@skip_UserObjects tinyint = 0
,@skip_XTPObjects  tinyint = 0

AS
-- 01. CONTROL TABLE:
-- timestamps for all data captures
IF @skip_control=0
SELECT 
	'01' as [Control],
	MIN(Run_Datetime) AS Start,
	MAX(Run_Datetime) AS Completion,
	DATEDIFF(ms,MIN(Run_Datetime),MAX(Run_Datetime)) AS [Interval (ms)],
	COUNT(*) AS Steps
FROM  
	Track_TempDB..tdb_Control

-- 2. tdb_usage TABLE
-- SUMMARY of objects created/destroyed by sessions (detail)
IF @skip_ObjectsCreated = 0
SELECT 
	 '02' as [Objects Created]
	,Run_Number
	,COUNT(*) as [Session Count]
	,SUM(user_objects_alloc_page_count) as [User Alloc]
	,SUM(user_objects_dealloc_page_count) as [User DeAlloc]
	,SUM(user_objects_alloc_page_count - user_objects_dealloc_page_count) as [User Delta Alloc]
	,SUM(internal_objects_alloc_page_count) as [Internal Alloc]
	,SUM(internal_objects_dealloc_page_count) as [Internal DeAlloc]
	,SUM(internal_objects_alloc_page_count- internal_objects_dealloc_page_count) as [Internal Delta Alloc]
FROM 
	Track_TempDB..tdb_usage 
GROUP BY
	 Run_Number
ORDER BY 
	Run_Number

-- 03. tdb_PageAllocation TABLE
-- SUMMARY OF Allocation of USER/VERSION-STORE/INTERNAL objects per FILE
IF @skip_PageAllocation = 0
SELECT
	 '03' as [Page Allocation]
	,Run_Number
	,COUNT(*) as [Files]
	,SUM(total_page_count) as [Total Pages]
	,SUM(allocated_extent_page_count) AS [Allocated Pages]
	,SUM(unallocated_extent_page_count) AS [Unallocated Pages]
	,SUM(version_store_reserved_page_count) as [Version Store Pages]
	,SUM(user_object_reserved_page_count) as [User Object Pages]
	,SUM(internal_object_reserved_page_count) as [Internal Object Pages]
	,SUM(mixed_extent_page_count) AS [Mixed Extent Pages]
FROM 
	Track_TempDB..tdb_PageAllocation -- sp_help tdb_PageAllocation -- sp_updatestats tdb_PageAllocation 
GROUP BY
	 Run_Number
ORDER BY
	 Run_Number

-- 4. tdb_PerformanceCounters TABLE
-- capture PERFMON counters related to TempDB
IF @skip_PerformanceCounters = 0
SELECT	distinct
	'04.A' as [Performance Counters]
	,object_name
	,counter_name
	,Min(cntr_value) AS Min_Counter
	,MAX(cntr_value) AS MAX_Counter
	,MAX(cntr_value)-Min(cntr_value)  AS DELTA_Counter
FROM 
	Track_TempDB..tdb_PerformanceCounters 
WHERE
	counter_name lIKE '%Temp Tables%' 
	OR
	-- FILE COUNTERS
	(
		(counter_name like '%Log File(s) Size (KB)%' AND instance_name = 'tempdb')
		OR
		(counter_name like '%Log File(s) Used Size (KB)%' AND instance_name = 'tempdb')
		OR
		(counter_name like '%Free Space in tempdb (KB)%')
	)
	OR
	-- VERSION STORE COUNTERS
	(
		counter_name  	like '%Version Generation Rate%'
		OR
		counter_name	like '%Version Cleanup Rate%'
		OR
		counter_name  	like '%Version Store Size%'
	)
	OR
	-- WORKTABLES
	(
		(counter_name  	like '%Worktables From Cache Ratio%') -- Percentage of work tables created where the initial two pages of the work table were not allocated but were immediately available from the work table cache. (When a work table is dropped, two pages may remain allocated and they are returned to the work table cache. This increases performance.)
		OR
		(counter_name  	like '%Worktables From Cache Base%')
		OR
		(counter_name  	like '%Worktables Created/sec%') -- Number of work tables created per second. For example, work tables could be used to store temporary results for query spool, lob variables, XML variables, and cursors.
		OR
		(counter_name  	like 'Workfiles Created/sec%') -- Number of work files created per second. For example, work files could be used to store temporary results for hash joins and hash aggregates.
	)
	OR 
	-- ALLOCATION / DEALLOCATION
	(
		(counter_name like '%Pages Allocated/sec%') -- Number of pages allocated per second in all databases in this instance of SQL Server. These include pages allocations from both mixed extents and uniform extents.
		OR
		(counter_name like '%Page Deallocations/sec%') -- Number of pages deallocated per second in all databases in this instance of SQL Servere. These include pages from mixed extents and uniform extents.
		OR
		(counter_name like '%Mixed page allocations/sec%') -- Number of pages allocated per second from mixed extents. These could be used for storing the IAM pages and the first eight pages that are allocated to an allocation unit.
		OR
		(counter_name like '%Extent Deallocations/sec%') --Number of extents deallocated per second in all databases in this instance of SQL Server.
		OR 
		(counter_name like '%Extents Allocated/sec%') -- Number of extents allocated per second in all databases in this instance of SQL Server.
		OR 
		(counter_name like '%Deferred Dropped Aus%') -- The number of allocation units waiting to be dropped by the background task that cleans up deferred dropped allocation units.
		OR 
		(counter_name like '%AU cleanups/sec%') -- The number of allocation units per second that were successfully dropped the background task that cleans up deferred dropped allocation units. Each allocation unit drop requires multiple batches.
		OR 
		(counter_name like '%AU cleanup batches/sec%') -- The number of batches per second that were completed successfully by the background task that cleans up deferred dropped allocation units.
	)
GROUP BY
	object_name, counter_name, instance_name
HAVING
	MAX(cntr_value)-Min(cntr_value)<>0

IF @skip_PerformanceCounters = 0 -- XTP counters
SELECT	distinct
	'04.B' as [Performance Counters]
	,object_name
	,counter_name
	,Min(cntr_value) AS Min_Counter
	,MAX(cntr_value) AS MAX_Counter
	,MAX(cntr_value)-Min(cntr_value)  AS DELTA_Counter
FROM 
	Track_TempDB..tdb_PerformanceCounters 
WHERE 
	counter_name like '%XTP%'
	OR
	object_name like '%XTP%'
GROUP BY
	object_name, counter_name, instance_name
HAVING
	MAX(cntr_value)-Min(cntr_value)<>0;


-- 05 tdb_sysprocesses
-- capture PAGE%LATCH waits to TempDB
IF @skip_Latches=0
WITH CTE_Latches AS (
	SELECT
		 Run_Number
		,lastwaittype
		,CAST( SUBSTRING(waitresource, Charindex(':', waitresource, 3)+1 , Len(waitresource)- Charindex(':', waitresource, 3)) AS INT) AS PageID 
		,waittime
	FROM 
		track_tempdb..tdb_sysprocesses
	WHERE 
		lastwaittype like 'PAGE%LATCH_%' 
		AND 
		waitresource like '2:%'
)
,CTE_PageType AS (
	SELECT
		Run_Number,
		lastwaittype,
		Case 
			When PageID = 1 Or PageID % 8088 = 0 Then 'PFS'
			When PageID = 2 Or PageID % 511232 = 0 Then 'GAM'
			When PageID = 3 Or (PageID - 1) % 511232 = 0 Then 'SGAM'
			Else 'Data/Index'
		End AS ResourceType,
		waittime
	FROM
		CTE_Latches
)
SELECT 
	'05' as [Latches],  
	Run_Number,
	lastwaittype,
	ResourceType,
	COUNT(*)  AS [Count of Latches],
	SUM(waittime) AS [Total Wait Time]
FROM
	CTE_PageType
GROUP BY 
	Run_Number,
	lastwaittype,
	ResourceType
ORDER BY
	Run_Number,
	lastwaittype,
	ResourceType


-- 06 tdb_waiting_tasks
-- capture waits to TempDB
IF @skip_Waits = 0
SELECT	
	'06' as [Waits], 
	Run_Number,
	wait_type,
	COUNT(*)  AS [Count of Waits],
	SUM(wait_duration_ms) AS [Total Wait Time]
FROM 
	track_tempdb..tdb_waiting_tasks
GROUP BY
	Run_Number,
	wait_type
ORDER BY
	Run_Number,
	wait_type


-- 07. TempDB allocation by User Session 
-- tdb_PagesAllocDeallocBySession ( -- select * from track_tempdb..tdb_PagesAllocDeallocBySession
-- SUMMARY OF USER/INTERNAL objects ALLOC/DEALLOC by SESSION
IF @skip_UserObjects  = 0
SELECT 
	'07' as [User Session objects]
	,Run_Number
	,COUNT(*) as [Session Count]
	,SUM(user_objects_alloc_page_count) as [User Objects Pages Alloc]
	,SUM(user_objects_dealloc_page_count) as [User Objects Pages Dealloc]
	,SUM(user_objects_alloc_page_count - user_objects_dealloc_page_count) as [User Objects DELTA]
	,SUM(internal_objects_alloc_page_count) as [Internal Objects Pages Alloc]
	,SUM(internal_objects_dealloc_page_count) as [Internal Objects Pages Dealloc]
	,SUM(internal_objects_alloc_page_count - internal_objects_dealloc_page_count) as [Internal Objects DELTA]
FROM 
	Track_TempDB..tdb_PagesAllocDeallocBySession
GROUP BY 
	Run_Number
ORDER BY
	Run_Number

IF @skip_XTPObjects  = 0
BEGIN

	SELECT 
		'XTP-1: memory_stats'
		,* 
	FROM 
		xtp_table_memory_stats
	ORDER BY
		 database_id
		,object_id
		,Run_Number

	SELECT 
		'XTP-1: memory_stats TBL-SUMMARY'
		,Run_Number
		,database_id
		,database_name
		,object_id
		,object_name
		,SUM(memory_allocated_for_table_kb + memory_allocated_for_indexes_kb)/1024.00 AS 'Memory Allocated MB'
		,SUM(memory_used_by_table_kb + memory_used_by_indexes_kb)/1024.00 AS 'Memory Used MB'
	FROM 
		xtp_table_memory_stats
	GROUP BY
		 Run_Number
		,database_id
		,database_name
		,object_id
		,object_name
	ORDER BY
		 database_id
		,object_name
		,Run_Number

	SELECT 
		'XTP-1: memory_stats DB-SUMMARY'
		,Run_Number
		,database_id
		,database_name
		,SUM(memory_allocated_for_table_kb + memory_allocated_for_indexes_kb)/1024.00 AS 'Memory Allocated MB'
		,SUM(memory_used_by_table_kb + memory_used_by_indexes_kb)/1024.00 AS 'Memory Used MB'
	FROM 
		xtp_table_memory_stats
	GROUP BY
		 Run_Number
		,database_id
		,database_name
	ORDER BY
		 database_id
		,Run_Number

	SELECT 
		'XTP-2: Res.Pool' 
		,Run_Number
		,pool_id
		,convert(char(10), name) as Pool_Name 
		,min_memory_percent
		,max_memory_percent 
		,max_memory_kb/1024 AS max_memory_MB
		,used_memory_kb/1024 as used_memory_MB
		,target_memory_kb/1024 as target_memory_MB
	FROM 
		xtp_resource_governor_resource_pools
	ORDER BY
		 pool_id
		,Run_Number


	SELECT DISTINCT 
		'XTP-2: Res.Pool Summary' 
		,pool_id
		,convert(char(10), name) as Pool_Name 
		,min_memory_percent
		,max_memory_percent 
		,max_memory_kb/1024 AS max_memory_MB
		,MIN(used_memory_kb/1024) OVER(PARTITION BY pool_id) as 'MIN used_memory_MB'
		,AVG(used_memory_kb/1024) OVER(PARTITION BY pool_id) as 'AVG used_memory_MB'
		,MAX(used_memory_kb/1024) OVER(PARTITION BY pool_id)as 'MAX used_memory_MB'
		,target_memory_kb/1024 as target_memory_MB
	FROM 
		xtp_resource_governor_resource_pools
	ORDER BY
		 pool_id


	SELECT 
		'XTP-3: memory_consumers'
		,* 
	FROM 
		xtp_system_memory_consumers	
	ORDER BY
		 memory_consumer_id
		,Run_Number

	SELECT 
		'XTP-4: memory_clerks'
		,* 
	FROM 
		xtp_memory_clerks
	ORDER BY
		 name 
		,memory_node_id
		,Run_Number

	SELECT DISTINCT
		'XTP-4: memory_clerks STATS'
		,name
		,memory_node_id
		,MIN(pages_kb/1024) OVER(PARTITION BY name,memory_node_id) as MIN_Pages_MB
		,AVG(pages_kb/1024) OVER(PARTITION BY name,memory_node_id) as AVG_Pages_MB
		,MAX(pages_kb/1024) OVER(PARTITION BY name,memory_node_id) as MAX_Pages_MB
	FROM 
		xtp_memory_clerks
	ORDER BY
		 name 
		,memory_node_id

	SELECT 
		 'XTP-5: hash_index_stats'
		,*
	FROM
		track_tempdb..xtp_hash_index_stats

	SELECT
		 'XTP-6: index_stats'
		,*
	FROM 
		track_tempdb..xtp_index_stats
	ORDER BY
		 database_id 
		,object_name
		,index_id
		,Run_Number


	SELECT
		 'XTP-7: xtp_checkpoint_files'
		 ,*
	FROM 
		track_tempdb..xtp_checkpoint_files
	ORDER BY
		  db_id
		 ,internal_storage_slot 
		 ,Run_Number


	SELECT
		 'XTP-8: xtp_object_stats'
		 ,*
	FROM 
		track_tempdb..xtp_object_stats
	ORDER BY
		 database_id
		,object_name
		,Run_Number


END


