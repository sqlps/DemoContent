use TempDB
go
select * from sys.objects where type = 'U'
DBCC FREEPROCCACHE
select * from sys.dm_exec_sessions
select * from sys.dm_os_waiting_tasks

/*
GO
EXEC sys.sp_configure N'max server memory (MB)', N'16384'
GO
RECONFIGURE WITH OVERRIDE
GO
*/
SELECT 
	 d.database_id
	,d.name AS DbName
	,d.resource_pool_id AS PoolId
       ,p.name AS PoolName
	,p.min_memory_percent
	,p.max_memory_percent
FROM 
	sys.databases d
	LEFT OUTER JOIN sys.resource_governor_resource_pools p 
		ON p.pool_id = d.resource_pool_id
