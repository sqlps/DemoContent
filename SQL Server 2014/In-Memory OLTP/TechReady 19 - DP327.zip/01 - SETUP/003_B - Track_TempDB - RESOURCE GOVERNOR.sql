/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

---- Memory usage scripts
USE master
GO
SET NOCOUNT ON
GO

USE Track_TempDB

-- show DB memory report
select object_name(object_id) as 'Object name', memory_used_by_table_kb,memory_used_by_indexes_kb
from sys.dm_db_xtp_table_memory_stats 
where object_id = object_id('Order Details')

-- memory usage
select object_name(object_id) as 'Object name', memory_used_by_table_kb,memory_used_by_indexes_kb
from sys.dm_db_xtp_table_memory_stats 
where object_id = object_id('Order Details')


-- show memory usage report in SSMS as well
--------------------- end --------------------


--Memory RG integration
use master
dbcc traceoff (9864, -1)
go

-- configure IM pool to be ~1.6GB
EXEC sp_configure 'show advanced options', 1
EXEC sp_configure 'max server memory (MB)', 4000
EXEC sp_configure 'min server memory (MB)', 4000
RECONFIGURE
go

-- check the max server memory
select * from sys.configurations where name like '%server memory (MB)'

-- create the resoure pool
CREATE RESOURCE POOL Pool_Track_TempDB WITH (MIN_MEMORY_PERCENT = 40, MAX_MEMORY_PERCENT = 40);
ALTER RESOURCE GOVERNOR RECONFIGURE;
go


-- check pool memory settings
select pool_id,name, min_memory_percent, max_memory_percent, max_memory_kb/1024 as max_memory_in_MB, used_memory_kb/1024 as used_memory_in_MB, target_memory_kb/1024 as target_memory_in_MB 
from sys.dm_resource_governor_resource_pools 
-- where name in ('internal','Pool_Track_TempDB',)

-- check DB and pool binding
SELECT d.database_id, d.name AS DbName, d.resource_pool_id AS PoolId
       , p.name AS PoolName, p.min_memory_percent, p.max_memory_percent
FROM sys.databases d
       LEFT OUTER JOIN sys.resource_governor_resource_pools p ON p.pool_id = d.resource_pool_id

-- bind the database to the pool
EXEC sp_xtp_bind_db_resource_pool 'Track_TempDB', 'Pool_Track_TempDB'

alter database Track_TempDB set offline
go
alter database Track_TempDB set online
go


USE Track_TempDB
go

