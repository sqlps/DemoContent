Stop-Service -Name 'MSSQL$INST_2014_A'
Start-Service -Name 'MSSQL$INST_2014_A'
$service_SQL = Get-Service -Name 'MSSQL$INST_2014_A'
$service_SQL 
