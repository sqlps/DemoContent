/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

/*
	THIS SCRIPT contains several SPs:
	---------------------------------
	spi_xtp_checkpoint_files
	spi_xtp_object_stats
	spi_xtp_index_stats
	spi_xtp_hash_index_stats
	spi_xtp_table_memory_stats
	spi_Track_TempDB
	spr_Track_TempDB

	ALL above procedures that have sp_xtp_ prefix name MUST be created on all databases that contain IN-MEMORY objects
	The spi_Track_TempDB and spr_Track_TempDB Stored Procedures only need to be created on Track_TempDB Database

	NOTICE that spi_Track_TempDB calls for all spi_xtp stored procedures, and you'll need to adjust spi_track_tempDB to add
		other databases that also use in-memory object if that's the case

*/

-- THESE SPs MUST to be created in all databases that contain in-memory OLTP object
-- USE AdventureWorks2014 
USE Track_TempDB 
GO 
DROP PROCEDURE spi_xtp_checkpoint_files
GO
CREATE PROCEDURE spi_xtp_checkpoint_files
@Run_Number INT = NULL

AS
declare @tmp_stt varchar(5000)
if @Run_Number IS NULL
BEGIN
	SELECT @Run_Number = MAX(Run_Number) FROM Track_TempDB..xtp_checkpoint_files WHERE db_id = db_id()
	if @Run_Number IS NULL
	BEGIN
		SELECT @Run_Number = 0
	END
	SELECT @Run_Number += 1
END
INSERT Track_TempDB..xtp_checkpoint_files (
	 Run_Number						
	,db_id							
	,internal_storage_slot			
	,file_size_MB					
	,file_size_used_MB				
	,inserted_row_count				
	,deleted_row_count				
	,data_delta_file_pairs			
	,percent_full					
)
SELECT
 	 @Run_Number 
	,db_id()
	,*
	,CASE inserted_rows
		WHEN 0 THEN 0
		ELSE 
			CASE file_size_MB
				WHEN 0 THEN 0
				ELSE str((convert (float, (file_size_used_MB * (1 - convert (float, deleted_rows)/inserted_rows)))/file_size_MB), 25, 2) 
			END
	END as percent_full
FROM
	( 
		SELECT	
			t.internal_storage_slot, 
			file_size_in_bytes/(1024.00*1024.00) as file_size_MB, 
			file_size_used_in_bytes/(1024.00*1024.00) as file_size_used_MB, 
			(case 
				when inserted_row_count= 0 then 1
				when inserted_row_count > 0 then inserted_row_count 
			end) as inserted_rows,
			(
				SELECT 
					deleted_row_count 
				FROM 
					sys.dm_db_xtp_checkpoint_files 
				where 
					internal_storage_slot = t.internal_storage_slot 
					and file_type=1
				) as deleted_rows,
			(
				select 
					count (*)
				from 
					sys.dm_db_xtp_checkpoint_files
				where 
					internal_storage_slot is not NULL and file_type = 0
			) as data_delta_file_pairs
			from 
				sys.dm_db_xtp_checkpoint_files as t
			where 
				internal_storage_slot is not NULL and file_type=0) as t_t
			order by 
				internal_storage_slot
GO


-- THESE SPs MUST to be created in all databases that contain in-memory OLTP object
-- USE AdventureWorks2014 
USE Track_TempDB 
GO
DROP PROCEDURE spi_xtp_object_stats
GO
CREATE PROCEDURE spi_xtp_object_stats
@Run_Number INT = NULL

AS
declare @tmp_stt varchar(5000)
if @Run_Number IS NULL
BEGIN
	SELECT @Run_Number = MAX(Run_Number) FROM Track_TempDB..tdb_xtp_object_stats
	if @Run_Number IS NULL
	BEGIN
		SELECT @Run_Number = 0
	END
	SELECT @Run_Number += 1
END
INSERT Track_TempDB..xtp_object_stats (
		Run_Number				
	,database_id			
	,object_id				
	,object_name			
	,row_insert_attempts	
	,row_update_attempts	
	,row_delete_attempts	
	,write_conflicts		
)
SELECT
	@Run_Number 
	,db_id()
	,object_id
	,object_name(object_id)
	,row_insert_attempts	
	,row_update_attempts	
	,row_delete_attempts	
	,write_conflicts		
FROM 
	sys.dm_db_xtp_object_stats
WHERE
	object_id > 0 
GO


-- THESE SPs MUST to be created in all databases that contain in-memory OLTP object
-- USE AdventureWorks2014 
USE Track_TempDB 
GO
DROP PROCEDURE spi_xtp_index_stats
GO
CREATE PROCEDURE spi_xtp_index_stats
@Run_Number INT = NULL

AS
declare @tmp_stt varchar(5000)
if @Run_Number IS NULL
BEGIN
	SELECT @Run_Number = MAX(Run_Number) FROM Track_TempDB..xtp_index_stats WHERE database_id = db_id()
	if @Run_Number IS NULL
	BEGIN
		SELECT @Run_Number = 0
	END
	SELECT @Run_Number += 1
END
INSERT track_tempdb..xtp_index_stats (
	Run_Number				
	,database_id			
	,database_name			
	,object_id				
	,object_name			
	,index_id				
	,index_name				
	,scans_started			
	,scans_retries			
	,rows_returned			
	,rows_touched			
	,rows_expiring			
	,rows_expired			
	,rows_expired_removed	
	,usage_pattern		
)
SELECT
	 @Run_Number
	,db_id()
	,db_name()
	,ix.object_id 
	,object_name(ix.object_id)
	,ix.index_id 
	,ix.name 
	,scans_started			
	,scans_retries			
	,rows_returned			
	,rows_touched			
	,rows_expiring			
	,rows_expired			
	,rows_expired_removed	
	,case scans_started
		when 0 then 'not used'
		else RTRIM(LTRIM(CAST(CAST( (rows_returned	/ scans_started) as INT) as CHAR(10))))  + '  X'
		END as 'usage pattern' -- select *
FROM 
	sys.dm_db_xtp_index_stats ixs INNER JOIN sys.indexes ix ON 
	ix.object_id=ixs.object_id AND ix.index_id=ixs.index_id
WHERE 
	scans_started <>0

go



-- THESE SPs MUST to be created in all databases that contain in-memory OLTP object
-- USE AdventureWorks2014 
USE Track_TempDB 
GO
DROP PROCEDURE spi_xtp_hash_index_stats
GO
CREATE PROCEDURE spi_xtp_hash_index_stats
@Run_Number INT = NULL

AS
declare @tmp_stt varchar(5000)
if @Run_Number IS NULL
BEGIN
	SELECT @Run_Number = MAX(Run_Number) FROM Track_TempDB..xtp_hash_index_stats
	if @Run_Number IS NULL
	BEGIN
		SELECT @Run_Number = 0
	END
	SELECT @Run_Number += 1
END

INSERT Track_TempDB..xtp_hash_index_stats (
	 Run_Number			
	,database_id
	,database_name
	,object_id			
	,object_name		
	,index_id			
	,index_name			
	,total_bucket_count	
	,empty_bucket_count	
	,avg_chain_length	
	,max_chain_length	
	,row_count			
	,distinct_keys		
)
SELECT
	@Run_Number
	,db_id()
	,db_name()
	,hs.object_id			
	,object_name(hs.object_id)
	,hs.index_id			
	,i.name --index_name			
	,total_bucket_count	
	,empty_bucket_count	
	,avg_chain_length	
	,max_chain_length	
	,0 -- row_count			
	,0 -- distinct_keys		
FROM 
	sys.dm_db_xtp_hash_index_stats AS hs
	JOIN sys.indexes AS i 
		ON hs.object_id=i.object_id AND hs.index_id=i.index_id;
-- [TODO]:
-- update [tdb_xtp_hash_index_stats] 
--	with row_count and distinct_keys
--		-- select count(*) as 'Row count' from <tableName>
--		-- select count(*) as 'Distinct index key values' from (select distinct <indexKeyColumns> from <tableName>) a
--
GO



-- THESE SPs MUST to be created in all databases that contain in-memory OLTP object
-- USE AdventureWorks2014 
USE Track_TempDB 
GO
DROP PROCEDURE spi_xtp_table_memory_stats
GO
CREATE PROCEDURE spi_xtp_table_memory_stats
@Run_Number INT = NULL

AS

declare @tmp_stt varchar(5000)


if @Run_Number IS NULL
BEGIN
	SELECT @Run_Number = MAX(Run_Number) FROM Track_TempDB..xtp_table_memory_stats
	if @Run_Number IS NULL
	BEGIN
		SELECT @Run_Number = 0
	END
	SELECT @Run_Number += 1
END
BEGIN TRY
	SET @tmp_stt  = N'	'
	SET @tmp_stt += N' INSERT Track_TempDB..xtp_table_memory_stats '
	SET @tmp_stt += N' SELECT '
	SET @tmp_stt += N'		 ' + CAST(@Run_Number AS CHAR(5))
	SET @tmp_stt += N'		,' + CAST(db_id() as CHAR(5))
	SET @tmp_stt += N'		,' + char(39) + db_name() + char(39)
	SET @tmp_stt += N'		,OBJECT_NAME(object_id)'
	SET @tmp_stt += N'		,object_id							'
	SET @tmp_stt += N'		,memory_allocated_for_table_kb		'
	SET @tmp_stt += N'		,memory_used_by_table_kb			'
	SET @tmp_stt += N'		,memory_allocated_for_indexes_kb	'
	SET @tmp_stt += N'		,memory_used_by_indexes_kb			'
	SET @tmp_stt += N' FROM '
	SET @tmp_stt += N'		sys.dm_db_xtp_table_memory_stats'
	SET @tmp_stt += N' WHERE '
	SET @tmp_stt += N'		object_id > 0 '
	EXEC (@tmp_stt)
END TRY
BEGIN CATCH
	PRINT @@error
END CATCH
GO

-- references:
-- http://msdn.microsoft.com/en-us/library/ms176029.aspx


-- replace Track_TempDB with the database name here
USE Track_TempDB
go
-- control table
DROP PROCEDURE spi_Track_TempDB
go

CREATE PROCEDURE spi_Track_TempDB
@str_note varchar(30) = 'Agent'
AS 

BEGIN

	DECLARE @str_entry varchar(30) = @str_note
	IF @str_entry IS NULL
	BEGIN
		SET @str_entry = 'Agent'
	END

	-- 01. CONTROL TABLE:
	-- timestamps for all data captures
	DECLARE @Run_Number INT
	INSERT tdb_Control
	SELECT getdate(), @str_entry 

	SELECT @Run_Number = @@IDENTITY 
	-- MAX(Run_Number) FROM tdb_Control

	/*
	sys.dm_db_task_space_usage 
	==========================
	Remarks
	--------------------------------------------------------------------------------
	IAM pages are not included in any of the page counts reported by this view.
	Page counters are initialized to zero (0) at the start of a request. These values are 
		aggregated at the session level when the request is completed. 
		For more information, see sys.dm_db_session_space_usage (Transact-SQL). 
	Work table caching, temporary table caching, and deferred drop operations affect the 
		number of pages allocated and deallocated in a specified task.

	User Objects
	--------------------------------------------------------------------------------
	The following objects are included in the user object page counters:
	- User-defined tables and indexes
	- System tables and indexes
	- Global temporary tables and indexes
	- Local temporary tables and indexes
	- Table variables
	- Tables returned in the table-valued functions

	Internal Objects
	--------------------------------------------------------------------------------
	Internal objects are only in tempdb. The following objects are included in the internal object page counters: 
	- Work tables for cursor or spool operations and temporary large object (LOB) storage
	- Work files for operations such as a hash join
	- Sort runs
	*/

	-- 02. tdb_usage TABLE
	-- SUMMARY of objects created/destroyed by sessions (detail)
	----INSERT tdb_usage ( -- select * from track_tempdb..tdb_usage
	----	 Run_Number
	----	,request_user_objects_alloc_page_count 
	----	,request_user_objects_dealloc_page_count 
	----	,request_internal_objects_alloc_page_count 
	----	,request_internal_objects_dealloc_page_count
	----	)
	----SELECT 
	----	 @Run_Number
	----	,SUM(user_objects_alloc_page_count) as request_user_objects_alloc_page_count
	----	,SUM(user_objects_dealloc_page_count) as request_user_objects_dealloc_page_count
	----	,SUM(internal_objects_alloc_page_count) AS request_internal_objects_alloc_page_count
	----	,SUM(internal_objects_dealloc_page_count)AS request_internal_objects_dealloc_page_count 
	----FROM	
	----	sys.dm_db_task_space_usage 
	----WHERE
	----	database_id=2	
	INSERT tdb_usage ( -- select * from track_tempdb..tdb_usage
		 Run_Number 
		,task_address	
		,is_remote_task	
		,session_id	
		,request_id	
		,exec_context_id	
		,database_id	
		,user_objects_alloc_page_count	
		,user_objects_dealloc_page_count
		,internal_objects_alloc_page_count	
		,internal_objects_dealloc_page_count
	)
	SELECT
		 @Run_Number
		,task_address	
		,is_remote_task	
		,session_id	
		,request_id	
		,exec_context_id	
		,database_id	
		,user_objects_alloc_page_count	
		,user_objects_dealloc_page_count
		,internal_objects_alloc_page_count	
		,internal_objects_dealloc_page_count
	FROM	
		sys.dm_db_task_space_usage 
	WHERE
		database_id=2	
		AND
		session_id IS NOT NULL

	-- 03. tdb_PageAllocation TABLE
	-- SUMMARY OF Allocation of USER/VERSION-STORE/INTERNAL objects per FILE
	-- create table tdb_PageAllocation (
	INSERT tdb_PageAllocation 
	SELECT
		 @Run_Number  
		,file_id 
		,filegroup_id 
		,SUM(total_page_count)
		,SUM(allocated_extent_page_count)  
		,SUM(unallocated_extent_page_count)
		,SUM(version_store_reserved_page_count) 
		,SUM(user_object_reserved_page_count) 
		,SUM(internal_object_reserved_page_count) 
		,SUM(mixed_extent_page_count) -- select *
	FROM
		tempdb.sys.dm_db_file_space_usage
	WHERE 
		database_id=2
	GROUP BY 
		 file_id 
		,filegroup_id 

	-- 04. tdb_PerformanceCounters
	-- capture PERFMON counters related to TempDB
	INSERT tdb_PerformanceCounters
	SELECT	
		 @Run_Number -- Run_Number 
		,object_name 
		,counter_name
		,instance_name 
		,cntr_value 
		,cntr_type 
	FROM
		sys.dm_os_performance_counters	;
	/*
	-- SQL Server, Access Methods Object: http://technet.microsoft.com/en-us/library/ms177426.aspx
	looking at the source code, there is a perfmon counter it increments if a worktable is alloc from cache
	Worktables From Cache Ratio
	Worktables From Cache Base
	*/


	/*
		sys.dm_db_task_space_usage:
		============================================================================================================

		IAM pages are not included in any of the page counts reported by this view.
		Page counters are initialized to zero (0) at the start of a request. These values are aggregated at 
			the session level when the request is completed. For more information, see sys.dm_db_session_space_usage 
			(Transact-SQL). 

		Work table caching, temporary table caching, and deferred drop operations affect the number of pages allocated 
			and deallocated in a specified task.

		User Objects. The following objects are included in the user object page counters:
		------------------------------------------------------------------------------
		User-defined tables and indexes
		System tables and indexes
		Global temporary tables and indexes
		Local temporary tables and indexes
		Table variables
		Tables returned in the table-valued functions

		Internal Objects - Internal objects are only in tempdb. The following objects are included in the internal object page counters: 
		------------------------------------------------------------------------------
		Work tables for cursor or spool operations and temporary large object (LOB) storage
		Work files for operations such as a hash join
		Sort runs
	*/


	-- 05. tdb_sysprocesses
	-- capture PAGE%LATCH waits to TempDB
	INSERT track_tempdb..tdb_sysprocesses -- select * from track_tempdb..tdb_sysprocesses 
	select 
		 @Run_Number, 
		[spid]  ,
		[kpid]  ,
		[blocked]  ,
		[waittype] ,
		[waittime] ,
		[lastwaittype] ,
		[waitresource],
		[dbid]  ,
		[uid]  ,
		[cpu]  ,
		[physical_io] ,
		[memusage]  ,
		[login_time] ,
		[last_batch] ,
		[ecid]  ,
		[open_tran]  ,
		[status]  ,
		[sid]  ,
		[hostname]  ,
		[program_name]  ,
		[hostprocess]  ,
		[cmd]  ,
		[nt_domain]  ,
		[nt_username]  ,
		[net_address]  ,
		[net_library]  ,
		[loginame]  ,
		[context_info]  ,
		[sql_handle]  ,
		[stmt_start]  ,
		[stmt_end]  ,
		[request_id]  
	FROM 
		sys.sysprocesses  
	--WHERE 
	--	lastwaittype like 'PAGE%LATCH_%' 
	--	AND 
	--	waitresource like '2:%'

	-- 06. tempdb waits
	INSERT track_tempdb..tdb_waiting_tasks -- select * FROM track_tempdb..tdb_waiting_tasks
	select 
		 @Run_Number
		,isnull(session_id,0)
		,wait_type 
		,SUM(wait_duration_ms)
		,resource_description  
	FROM 
		sys.dm_os_waiting_tasks 
	WHERE 
		wait_type IS NOT NULL
	GROUP BY
		 isnull(session_id,0)
		,wait_type 
		,resource_description  

	--	like 'PAGE%LATCH_%' 
	--	AND resource_description like '2:%'

	-- 07. TempDB allocation by User Session 
	-- tdb_PagesAllocDeallocBySession ( -- select * from track_tempdb..tdb_PagesAllocDeallocBySession
	INSERT tdb_PagesAllocDeallocBySession
	SELECT
		 @Run_Number
		,session_id 
		,database_id
		,user_objects_alloc_page_count 
		,user_objects_dealloc_page_count 
		,internal_objects_alloc_page_count 
		,internal_objects_dealloc_page_count 
	FROM 
		tempdb.sys.dm_db_session_space_usage 

	-- 10
	EXEC AdventureWorks2014..spi_xtp_table_memory_stats @Run_Number
	EXEC Track_TempDB..spi_xtp_table_memory_stats @Run_Number
	-- SELECT * FROM TRACK_TEMPDB..xtp_table_memory_stats

	-- 11
	INSERT Track_TempDB..xtp_resource_governor_resource_pools
	SELECT
		 @Run_Number
		,pool_id	
		,name	
		,statistics_start_time	
		,total_cpu_usage_ms	
		,cache_memory_kb	
		,compile_memory_kb	
		,used_memgrant_kb	
		,total_memgrant_count	
		,total_memgrant_timeout_count	
		,active_memgrant_count	
		,active_memgrant_kb	
		,memgrant_waiter_count	
		,max_memory_kb	
		,used_memory_kb	
		,target_memory_kb	
		,out_of_memory_count	
		,min_cpu_percent	
		,max_cpu_percent	
		,min_memory_percent	
		,max_memory_percent	
		,cap_cpu_percent	
		,min_iops_per_volume	
		,max_iops_per_volume	
		,read_io_queued_total	
		,read_io_issued_total	
		,read_io_completed_total	
		,read_io_throttled_total	
		,read_bytes_total	
		,read_io_stall_total_ms	
		,read_io_stall_queued_ms	
	FROM 
		sys.dm_resource_governor_resource_pools

	-- 12
	INSERT xtp_system_memory_consumers  -- select * from xtp_system_memory_consumers 
	SELECT
		 @Run_Number
		,memory_consumer_id		
		,memory_consumer_type	
		,SUBSTRING(memory_consumer_type_desc	,1,64)
		,SUBSTRING(memory_consumer_desc			,1,64)
--		,lookaside_id				
		,pagepool_id				
		,allocated_bytes			
		,used_bytes					
		,allocation_count			
		,partition_count			
--		,sizeclass_count			
--		,min_sizeclass				
--		,max_sizeclass				
--		,memory_consumer_address	
	FROM
		sys.dm_xtp_system_memory_consumers

	-- 13
	INSERT Track_TempDB..xtp_memory_clerks -- SELECT * FROM tdb_memory_clerks
	(
		 Run_Number			
		,name				
		,memory_node_id		
		,pages_kb			
	)
	SELECT
		 @Run_Number
		,name				
		,memory_node_id		
		,SUM(pages_kb)
	FROM
		sys.dm_os_memory_clerks 
	WHERE 
		type LIKE '%xtp%'
		AND
		memory_node_id <> 64
	GROUP BY 
		 name				
		,memory_node_id		

	-- 14
	EXECUTE AdventureWorks2014..spi_xtp_hash_index_stats @Run_Number
	EXECUTE Track_TempDB..spi_xtp_hash_index_stats @Run_Number

	-- 15
	EXECUTE AdventureWorks2014..spi_xtp_index_stats @Run_Number
	EXECUTE Track_TempDB..spi_xtp_index_stats @Run_Number

	-- 16
	-- select * from Track_TempDB..xtp_checkpoint_files
	EXEC AdventureWorks2014..spi_xtp_checkpoint_files @Run_Number
	EXEC Track_TempDB..spi_xtp_checkpoint_files @Run_Number

	-- 17
	-- SELECT * FROM Track_TempDB..xtp_object_stats
	EXEC AdventureWorks2014..spi_xtp_object_stats @Run_Number
	EXEC Track_TempDB..spi_xtp_object_stats @Run_Number

END	

GO


USE Track_TempDB
go
DROP PROCEDURE spr_Track_TempDB
go
CREATE PROCEDURE spr_Track_TempDB
AS

DELETE FROM track_tempdb..tdb_Control
DELETE FROM track_tempdb..tdb_usage
DELETE FROM track_tempdb..tdb_PageAllocation
DELETE FROM track_tempdb..tdb_PerformanceCounters
DELETE FROM track_tempdb..tdb_sysprocesses 
DELETE FROM track_tempdb..tdb_waiting_tasks 
DELETE FROM tdb_PagesAllocDeallocBySession
-- XTP
DELETE FROM Track_TempDB..xtp_table_memory_stats
DELETE FROM track_tempdb..xtp_resource_governor_resource_pools
DELETE FROM track_tempdb..xtp_system_memory_consumers
DELETE FROM track_tempdb..xtp_memory_clerks
DELETE FROM track_tempdb..xtp_hash_index_stats
DELETE FROM track_tempdb..xtp_index_stats
DELETE FROM Track_TempDB..xtp_checkpoint_files
DELETE FROM Track_TempDB..xtp_object_stats
GO






/*
-------------------------------------------------------------------------------------
-- Monitor and Tune for Performance
-- http://msdn.microsoft.com/en-us/library/ms189081(v=sql.120).aspx



Monitoring and Tuning Performance Tasks
--------------------------------------------------------------------------------
Task Description										Topic
-------------------------------------------------------------------------------- 
Provides the necessary steps required to effectively	http://msdn.microsoft.com/en-us/library/hh213686.aspx
monitor any component of SQL Server.					
-------------------------------------------------------------------------------- 
Lists the SQL Server monitoring and tuning tools.		http://msdn.microsoft.com/en-us/library/ms179428.aspx
														
--------------------------------------------------------------------------------
Provides information about how to establish a			http://msdn.microsoft.com/en-us/library/ms190943.aspx
performance baseline.									
--------------------------------------------------------------------------------
Describes how to isolate database performance			http://msdn.microsoft.com/en-us/library/ms178100.aspx
problems.
						Monitor Memory Usage			http://msdn.microsoft.com/en-us/library/ms176018.aspx	
-------------------------------------------------------------------------------- 
Describes how to monitor and track server				http://msdn.microsoft.com/en-us/library/ms190994.aspx
performance to identify bottlenecks.
--------------------------------------------------------------------------------  
Describes how to use SQL Server and Windows				Server Performance and Activity Monitoring 
performance and activity monitoring tools.				*** EVERYTHING ABOUT SQL TRACE ************
														http://msdn.microsoft.com/en-us/library/ms191511.aspx
--------------------------------------------------------------------------------  
Describes how to display and save execution plans to	Display and Save Execution Plans 
a file in XML format.
--------------------------------------------------------------------------------   


MONITORING SQL SERVER: 

Monitor Resource Usage (System Monitor)					http://msdn.microsoft.com/en-us/library/ms191246.aspx
SELECT * FROM sys.sysperfinfo
SELECT * FROM sys.dm_os_performance_counters 
WHERE counter_name like '%XTP%'
UNION ALL 
SELECT * FROM sys.dm_os_performance_counters 
WHERE object_name like '%XTP%'


*/



	
