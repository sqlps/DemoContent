/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- REFERENCES:
-- http://blogs.msdn.com/b/askjay/archive/2010/02/18/creating-a-custom-performance-monitor-counter-for-sql-server.aspx
-- http://msdn.microsoft.com/en-us/library/ms187480(SQL.90).aspx

DECLARE @TEMPDB int; 
set @TEMPDB = 
(
SELECT COUNT(session_id) FROM sys.dm_exec_requests
WHERE wait_type like 'PAGE%LATCH_%' and
            wait_resource like '2:%'
) 
exec sp_user_counter1 @TEMPDB
-- TO RESET COUNTER: 
-- exec sp_user_counter1 0
--PRINT @TEMPDB
WAITFOR DELAY '00:00:05'
-- go 1000000000

/* 
SELECT * FROM sys.dm_os_performance_counters
WHERE
	object_name LIKE '%SET%'
	AND
	instance_name = 'User counter 1'

*/