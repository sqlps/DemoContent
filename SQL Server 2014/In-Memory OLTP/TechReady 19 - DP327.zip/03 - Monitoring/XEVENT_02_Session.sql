/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- A-Z of In-Memory OLTP : Extended Events (XEvents)
-- http://sqlserver-help.com/2014/02/18/a-z-of-in-memory-oltp-extended-events-xevents/
-- select * from SQL_World where name = �Balmukund�
 
--- THIS SESSION WILL CAPTURE:
--   in-memory table load after SQL Restart
--	Native Compiled SP, when it is first time run


CREATE EVENT SESSION [SQLServerHelp] ON SERVER 

     ADD EVENT sqlserver.database_started 
        (ACTION(sqlos.cpu_id, sqlserver.database_id) 
            WHERE ([database_id] = (5)))
    ,ADD EVENT XtpRuntime.load_dll 
        (ACTION(sqlos.cpu_id, sqlserver.client_hostname)) 
        
    ADD TARGET package0.event_file (SET filename = N'SQLServerHelp')
    
    WITH (
            MAX_MEMORY = 4096 KB
            ,EVENT_RETENTION_MODE = ALLOW_SINGLE_EVENT_LOSS
            ,MAX_DISPATCH_LATENCY = 30 SECONDS
            ,MAX_EVENT_SIZE = 0 KB
            ,MEMORY_PARTITION_MODE = NONE
            ,TRACK_CAUSALITY = OFF
            ,STARTUP_STATE = ON
            )
GO
