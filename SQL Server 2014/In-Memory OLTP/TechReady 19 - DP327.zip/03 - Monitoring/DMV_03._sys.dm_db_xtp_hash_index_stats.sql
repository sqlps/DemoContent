/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- sys.dm_db_xtp_hash_index_stats
-- http://msdn.microsoft.com/en-us/library/dn296679.aspx

-- Troubleshooting the Bucket Count
--------------------------------------------------------------------------------
-- To troubleshoot bucket count issues in memory-optimized tables, 
--		use sys.dm_db_xtp_hash_index_stats 
--	to obtain statistics about the empty buckets and the length of row chains. 
--		The following query can be used to obtain statistics about all the 
--		hash indexes in the current database. 
--		The query can take several minutes to run if there are large tables in the database.
SELECT 
   object_name(hs.object_id) AS 'object name', 
   i.name as 'index name', 
   hs.total_bucket_count,
   hs.empty_bucket_count,
   floor((cast(empty_bucket_count as float)/total_bucket_count) * 100) AS 'empty_bucket_percent',
   hs.avg_chain_length, 
   hs.max_chain_length
FROM sys.dm_db_xtp_hash_index_stats AS hs 
   JOIN sys.indexes AS i 
   ON hs.object_id=i.object_id AND hs.index_id=i.index_id


-- http://blogs.technet.com/b/dataplatforminsider/archive/2013/10/09/troubleshooting-common-performance-problems-with-memory-optimized-hash-indexes.aspx
-- Troubleshooting Common Performance Problems with Memory-Optimized Hash Indexes

-- Hash index bucket count too low
-- 
-- Issue: 
--		If the bucket count is significantly lower (think 10X) than the number of unique 
--			index keys, there will be many buckets that have multiple index keys. 
--		This degrades performance of most DML operations, in particular point lookups, i.e. 
--			lookups of individual index keys.
-- Symptom: 
--		A performance degradation of queries that rely on lookups or inserts into the hash index. 
--		For example, SELECT queries and UPDATE/DELETE operations with equality predicates matching 
--		the index key columns in the WHERE clause.
--
--	How to troubleshoot: 
--		In some cases the problem is obvious from the index definition and the table data. 
--		For example, if the PRIMARY KEY has a HASH index with bucket_count 10,000, 
--		and the table has 1,000,000 rows, the bucket count is too low and will need to be changed.
--		In addition to inspecting table schema and data, you can use the 
--		DMV sys.dm_db_xtp_hash_index_stats. 
--	You can use the following query to obtain statistics concerning the buckets, and the row chains hanging off the buckets:

SELECT 
	hs.object_id, 
	object_name(hs.object_id) AS 'object name', 
	i.name as 'index name', 
	hs.*
FROM 
	sys.dm_db_xtp_hash_index_stats AS hs 
	JOIN sys.indexes AS i 
		ON hs.object_id=i.object_id 
		AND hs.index_id=i.index_id;

-- A large average chain length indicates that many rows are hashed to the same bucket. If, 
--		in addition, the number of empty buckets is low or the average and maximum chain lengths 
--		are similar, it is likely that the total bucket count is too low. In this case, you need 
--		to increase the bucket_count. 
--		Typically, you would want the bucket_count to be between 1 and 2 times the number 
--		of unique index key values. 
--		Note that the bucket_count is automatically rounded up to the nearest power of 2.



-- Search requires a subset of hash index key columns
-- 
-- Issue: Hash indexes require values for all index key columns in order to compute the hash value, 
--		and locate the corresponding rows in the hash table. Therefore, if a query includes equality 
--		predicates for only a subset of the index keys in the WHERE clause, SQL Server cannot use 
--		an index seek to locate the rows corresponding to the predicates in the WHERE clause.
--
--	In contrast, ordered indexes like the traditional disk-based (non)clustered indexes and 
--		the new memory-optimized nonclustered indexes (to be introduced in CTP2) support 
--		index seek on a subset of the index key columns, as long as they are the leading columns. 
--
--	Symptom: 
--		This results in a performance degradation, as SQL Server will need to execute full table 
--		scans, rather than an index seek, which is typically a far cheaper operation.  
--
--	How to troubleshoot: 
--		Besides the performance degradation, inspection of the query plans will also show 
--		a scan instead of an index seek. If the query is fairly simple, inspection of the 
--		query text and index definition will also show whether the search requires a subset 
--		of the index key columns

