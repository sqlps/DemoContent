/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/
--  
-- http://sqlserver-help.com/2014/02/18/a-z-of-in-memory-oltp-extended-events-xevents/
USE msdb 

SELECT p.name, 
       c.event, 
       k.keyword, 
       c.channel, 
       c.description 
FROM   (SELECT event_package=o.package_guid, 
               o.description, 
               event=c.object_name, 
               channel=v.map_value 
        FROM   sys.dm_xe_objects o 
               LEFT JOIN sys.dm_xe_object_columns c 
                      ON o.name = c.object_name 
               INNER JOIN sys.dm_xe_map_values v 
                       ON c.type_name = v.name 
                          AND c.column_value = Cast(v.map_key AS NVARCHAR) 
        WHERE  object_type = 'event' 
               AND ( c.name = 'CHANNEL' 
                      OR c.name IS NULL )) c 
       LEFT JOIN (SELECT event_package=c.object_package_guid, 
                         event=c.object_name, 
                         keyword=v.map_value 
                  FROM   sys.dm_xe_object_columns c 
                         INNER JOIN sys.dm_xe_map_values v 
                                 ON c.type_name = v.name 
                                    AND c.column_value = v.map_key 
                                    AND 
                         c.type_package_guid = v.object_package_guid 
                         INNER JOIN sys.dm_xe_objects o 
                                 ON o.name = c.object_name 
                                    AND o.package_guid = c.object_package_guid 
                  WHERE  object_type = 'event' 
                         AND c.name = 'KEYWORD') k 
              ON k.event_package = c.event_package 
                 AND ( k.event = c.event 
                        OR k.event IS NULL ) 
       INNER JOIN sys.dm_xe_packages p 
               ON p.guid = c.event_package 
WHERE  name LIKE '%xtp%' 
        OR c.event LIKE '%xtp%' 
        OR c.description LIKE '%xtp%' 
        OR k.event LIKE '%xtp%' 
        OR k.keyword LIKE '%xtp%' 
ORDER  BY 1, 
          keyword DESC, 
          channel, 
          event  