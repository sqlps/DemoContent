/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- Enable TraceFlag 3604 to be able to see 
-- DBCC pages in SSMS result pane
DBCC TRACEON(3604)
GO

-- set focus to TempDB
-- Truncate TempDB TLOG
USE TempDB
GO
CHECKPOINT
GO

-- show TempDB TLOG entries
SELECT
	[spid],
	[Current LSN],
	[Operation], 
	[Context], 
	[AllocUnitId], 
	[AllocUnitName], 
	[Page ID],
	[Slot ID],
	[Xact Type],
	[Transaction ID], 
	[Transaction Name], 
	[Description],
	[Begin Time],
	[End Time]
FROM 
	sys.fn_dblog(null, null)
go

-- show TempDB TLOG VLF contents
DBCC LOGINFO(2)

-- show USER objects in TempDB
SELECT 
	* 
FROM 
	tempdb.sys.objects 
WHERE 
	type NOT IN ('S','SQ','IT') -- , 'U' 
DECLARE @temp_Object int = -1553852018
SELECT 'sys.indexes' , * FROM sys.indexes WHERE object_id = @temp_Object 
SELECT 'sys.columns' , * FROM sys.columns WHERE Object_ID = @temp_Object 
SELECT 'sys.system_internals_allocation_units',* FROM sys.system_internals_allocation_units WHERE Container_ID IN (SELECT partition_id FROM sys.partitions WHERE Object_ID = @temp_Object )
SELECT 'sys.partitions',* FROM sys.partitions WHERE Object_ID = @temp_Object 
SELECT 'sys.system_internals_partitions',* FROM sys.system_internals_partitions WHERE Object_ID = @temp_Object 
SELECT 'sys.system_internals_partition_columns',* FROM sys.system_internals_partition_columns WHERE Partition_ID  IN (SELECT partition_id FROM sys.partitions WHERE Object_ID = @temp_Object )
SELECT   o.name AS table_name,-- to show data pages
         p.index_id,
         i.name AS index_name,
         au.type_desc AS allocation_type,
         au.data_pages,
         partition_number,
         au.root_page
FROM     sys.system_internals_allocation_units AS au
         INNER JOIN
         sys.partitions AS p
         ON au.container_id = p.partition_id
         INNER JOIN
         sys.objects AS o
         ON p.object_id = o.object_id
         INNER JOIN
         sys.indexes AS i
         ON p.index_id = i.index_id
            AND i.object_id = p.object_id
WHERE
	p.object_id = @temp_Object 
ORDER BY o.name, p.index_id;

-- PAGES allocated to the OBJECT
SELECT 
	allocated_page_file_id, 
	allocated_page_page_id, allocated_page_iam_file_id,
	'DBCC PAGE(2, ' + RTRIM(CAST(allocated_page_file_id AS CHAR(6))) + ', ' +  RTRIM(CAST(allocated_page_page_id AS CHAR(6))) + ', 3) WITH TABLERESULTS' + IIF(allocated_page_iam_file_id IS NULL,' -- IAM',' -- DATA PAGE' ) as SQL_Command
	,*
FROM 
	tempdb.sys.dm_db_database_page_allocations(2, NULL , NULL, NULL, 'DETAILED')
WHERE 
	Object_Id=@temp_Object 
--	and 
--	object_id not IN (SELECT ID from sysobjects WHERE type in ('S','IT','SQ'))

-- Syntax: 
--	DBCC PAGE( DB-ID, FIDBCC PAGE(2, 4 ,  600 ,3) WITH TABLERESULTSLE-ID , PAGE-ID , REPORT-STYLE) 
DBCC PAGE(2, 5, 528, 3) WITH TABLERESULTS -- IAM
DBCC PAGE(2, 1, 672, 3) WITH TABLERESULTS -- DATA PAGE


-- is the object still available?
SELECT 
	* 
FROM 
	tempdb.sys.objects 
WHERE 
	type = 'U'
ORDER BY 
	create_date DESC  



-- OBJECTS LEFT in TempDB after execution
SELECT 
	* 
FROM 
	tempdb.sys.objects 
WHERE 
	type NOT IN ('S','SQ','IT') -- , 'U' 

-- issue CheckPoint ,then Clean buffer pool
CHECKPOINT
GO
DBCC DROPCLEANBUFFERS
GO
-- CHECK AFTER CLEANING UP BUFFER POOL
SELECT 
	* 
FROM 
	tempdb.sys.objects 
WHERE 
	type NOT IN ('S','SQ','IT') -- , 'U' 

-- CLEAN THE PROCEDURE CACHE
DBCC FREEPROCCACHE;
GO
-- CHECK objects AFTER CLEANING UP BUFFER POOL
SELECT 
	* 
FROM 
	tempdb.sys.objects 
WHERE 
	type NOT IN ('S','SQ','IT') -- , 'U' 

