/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- http://msdn.microsoft.com/en-us/library/dn494956.aspx
-- contains a demo creating in-memory table and inserting rows
--	then it uses the sys.dm_db_xtp_hash_index_stats to evaluate 
--		INDEXES and BucketCounts

CREATE TABLE [Sales].[SalesOrderHeader_test]
(
   [SalesOrderID] [uniqueidentifier] NOT NULL DEFAULT (newid()),
   [OrderSequence] int NOT NULL,
   [OrderDate] [datetime2](7) NOT NULL,
   [Status] [tinyint] NOT NULL,
 
PRIMARY KEY NONCLUSTERED HASH ([SalesOrderID]) WITH ( BUCKET_COUNT = 262144 ),
INDEX IX_OrderSequence HASH (OrderSequence) WITH ( BUCKET_COUNT = 20000),
INDEX IX_Status HASH ([Status]) WITH ( BUCKET_COUNT = 8),
INDEX IX_OrderDate NONCLUSTERED ([OrderDate] ASC),
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA )
GO

DECLARE @i int = 0
BEGIN TRAN
WHILE @i < 262144
BEGIN
   INSERT Sales.SalesOrderHeader_test (OrderSequence, OrderDate, [Status]) VALUES (@i, sysdatetime(), @i % 8)
   SET @i += 1
END
COMMIT
GO

SELECT 
   object_name(hs.object_id) AS 'object name', 
   i.name as 'index name', 
   hs.total_bucket_count,
   hs.empty_bucket_count,
   floor((cast(empty_bucket_count as float)/total_bucket_count) * 100) AS 'empty_bucket_percent',
   hs.avg_chain_length, 
   hs.max_chain_length
FROM sys.dm_db_xtp_hash_index_stats AS hs 
   JOIN sys.indexes AS i 
   ON hs.object_id=i.object_id AND hs.index_id=i.index_id
WHERE
	object_name(hs.object_id) = 'SalesOrderHeader_test'	
GO

/*

========================================================================================
== HOW TO READ RESULTS 
========================================================================================
The two key indicators of hash index health are:

- empty_bucket_percent
----------------------
	Empty_bucket_percent indicates the number of empty buckets in the hash index.
	If empty_bucket_percent is less than 10 percent, the bucket count is likely to be too low. 
		Ideally, the empty_bucket_percent should be 33 percent or greater. 
		If the bucket count matches the number of index key values, about 1/3 of 
			the buckets is empty, due to hash distribution.

- avg_chain_length
------------------
	avg_chain_length indicates the average length of the row chains in the hash buckets.
	If avg_chain_length is greater than 10 and empty_bucket_percent is greater than 10 percent, 
		there likely are many duplicate index key values and a nonclustered index would be more 
		appropriate. An average chain length of 1 is ideal.

	There are two factors that impact the chain length:
	-----------------------------------------------------
	1.Duplicates; all duplicate rows are part of the same chain in the hash index.
	2.Multiple key values map to the same bucket. The lower the bucket count, the more buckets that will have multiple values mapped to them.
========================================================================================

DROP TABLE [Sales].[SalesOrderHeader_test]
*/
