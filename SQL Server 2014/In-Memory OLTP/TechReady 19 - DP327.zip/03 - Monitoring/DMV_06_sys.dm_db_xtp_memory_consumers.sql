/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- sys.dm_db_xtp_memory_consumers	
-- http://msdn.microsoft.com/en-us/library/dn133206.aspx 

--------------------------------------------------------------------------------
-- memory consumers (database level)
---------------------------------------
select  
	convert(char(10), object_name(object_id)) as Name, 
	convert(char(10),memory_consumer_type_desc ) as memory_consumer_type_desc, 
	object_id,index_id, allocated_bytes,  
	used_bytes 
from 
	sys.dm_db_xtp_memory_consumers
-- Here is the output with a subset of columns. 
--	The allocators at database levels refer to user tables, indexes, and system tables. 
--		The VARHEAP with object_id = NULL (last row) refers to memory allocated to data rows 
--		of the tables (in the example here, it is t1). 
--	The allocated bytes, when converted to MB, is 1340MB.



-- The total memory allocated and used from this DMV is same as the object level in 
--	sys.dm_db_xtp_table_memory_stats (Transact-SQL).
select  
	sum(allocated_bytes)/(1024*1024) as total_allocated_MB, 
    sum(used_bytes)/(1024*1024) as total_used_MB
from 
	sys.dm_db_xtp_memory_consumers

SELECT 
	 sum(memory_allocated_for_table_kb)/1024 as Table_allocated_MB
	,sum(memory_used_by_table_kb)/1024 as Table_used_MB
	,sum(memory_allocated_for_indexes_kb)/1024  as Indexes_allocated_MB
	,sum(memory_used_by_indexes_kb)/1024 as Indexes_used_MB
	,sum(memory_allocated_for_table_kb+memory_allocated_for_indexes_kb)/1024  as total_allocated_MB
	,sum(memory_used_by_table_kb+memory_used_by_indexes_kb)/1024  as total_used_MB
FROM 
	sys.dm_db_xtp_table_memory_stats

