/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- http://blogs.technet.com/b/dataplatforminsider/archive/2014/01/30/in-memory-oltp-index-troubleshooting-part-ii.aspx
-- In-Memory OLTP Index Troubleshooting, Part II

-- Troubleshooting seek vs. scan using XTP index DMVs
-- The DMV sys.dm_db_xtp_index_stats shows statistics for index operations performed 
--	by the in-memory storage engine. The index contains stats about the usage of the 
--	index since its creation in memory � note that memory-optimized indexes are always 
--	recreated on database restart. 
--	You can use the following query to retrieve key statistics about the usage of 
--	indexes on your table:

SELECT ix.index_id, ix.name, scans_started, rows_returned , *
FROM sys.dm_db_xtp_index_stats ixs JOIN sys.indexes ix ON 
ix.object_id=ixs.object_id AND ix.index_id=ixs.index_id
-- WHERE ix.object_id=object_id('<table name>')
