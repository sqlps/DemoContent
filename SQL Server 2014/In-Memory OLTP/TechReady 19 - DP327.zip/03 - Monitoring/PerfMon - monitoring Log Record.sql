/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

USE Track_TempDB
GO
IF OBJECT_ID('dbo.sample_XTP_PerfMonitor','U') IS NOT NULL
    DROP TABLE dbo.sample_XTP_PerfMonitor
GO
CREATE TABLE dbo.sample_XTP_PerfMonitor
(
 c1 int NOT NULL,
 c2 float NOT NULL,
 c3 decimal(10, 2) NOT NULL
CONSTRAINT PK_sample_XTP_PerfMonitor PRIMARY KEY NONCLUSTERED HASH
(
 c1 
)WITH ( BUCKET_COUNT = 1024)
)WITH ( MEMORY_OPTIMIZED = ON , DURABILITY = SCHEMA_AND_DATA ) -- DURABILITY = SCHEMA_ONLY ) 
GO


-- SELECT * FROM dbo.sample_XTP_PerfMonitor

Select Getdate() AS 'begin of Transaction 1'
INSERT INTO dbo.sample_XTP_PerfMonitor(c1, c2, c3)
  SELECT 9,9,9
Select Getdate() AS 'End of Transaction 1'

BEGIN TRAN
Select Getdate()  AS 'begin of Transaction 2'
INSERT INTO dbo.sample_XTP_PerfMonitor(c1, c2, c3)
  SELECT 10,10,10
-- Wait for 10 second
waitfor delay '00:00:10'
COMMIT TRAN
Select Getdate()  AS 'commit of Transaction 2'

BEGIN TRAN
Select Getdate() AS 'begin of Transaction 3'
INSERT INTO dbo.sample_XTP_PerfMonitor(c1, c2, c3)
  SELECT 11,11,11
-- Wait for 10 second
waitfor delay '00:00:10'
ROLLBACK TRAN
Select Getdate() AS 'rollback of Transaction 3'

-- DELETE dbo.sample_XTP_PerfMonitor WHERE c1>=9
