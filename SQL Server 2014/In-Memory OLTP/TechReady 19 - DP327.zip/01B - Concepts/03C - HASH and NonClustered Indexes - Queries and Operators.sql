USE Track_TempDB
GO
-- part III
-- http://www.mssqltips.com/sqlservertip/3099/understanding-sql-server-memoryoptimized-tables-hash-indexes

-- run these queries individually and use the ACTUAL PLAN to see how SQL will process them

-- Range searches
SELECT c1
FROM   dbo.sample_memoryoptimizedtable_Hash
WHERE  c1 > 4
SELECT c1
FROM   dbo.sample_memoryoptimizedtable_Range
WHERE  c1 > 4


-- Equality comparisons
SELECT c1
FROM   dbo.sample_memoryoptimizedtable_Hash
WHERE  c1 = 4
SELECT c1
FROM   dbo.sample_memoryoptimizedtable_Range
WHERE  c1 = 4


-- Inequality comparisons
SELECT c1
FROM   dbo.sample_memoryoptimizedtable_Hash
WHERE  c1 <> 4
SELECT c1
FROM   dbo.sample_memoryoptimizedtable_Range
WHERE  c1 <> 4


-- ORDER BY operation
SELECT   c1
FROM     dbo.sample_memoryoptimizedtable_Hash
WHERE    c1 = 4 OR c1 = 7
ORDER BY c1
SELECT   c1
FROM     dbo.sample_memoryoptimizedtable_Range
WHERE    c1 = 4 OR c1 = 7
ORDER BY c1 DESC



-- Composite Key Behavior
SELECT c1
FROM   dbo.Composite_Key_Hash
WHERE  c1 = 4
SELECT c1
FROM   dbo.Composite_Key_Range
WHERE  c1 = 4


-- LIKE
SELECT PersonID
FROM   dbo.StringTable_Hash
WHERE  PersonID LIKE 'C%'

SELECT PersonID
FROM   dbo.StringTable_Range
WHERE  PersonID LIKE 'C%'

SELECT PersonID
FROM   dbo.StringTable_Range
WHERE  PersonID LIKE '%C%'
