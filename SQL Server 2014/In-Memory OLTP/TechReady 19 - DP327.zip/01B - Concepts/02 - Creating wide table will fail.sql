/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/
USE Track_TempDB
GO

DROP TABLE tdb_WideTable
GO
CREATE TABLE tdb_WideTable
(
 Run_Number INT IDENTITY(1,1) NOT NULL 
	primary key nonclustered hash (Run_Number) 
	with (bucket_count = 1000) 
,Run_Datetime DATETIME NOT NULL DEFAULT GETDATE()
,Run_Note Varchar(30) NULL DEFAULT 'Agent'
,Run_Comment01 CHAR(800) NULL 
,Run_Comment02 CHAR(800) NULL 
,Run_Comment03 CHAR(800) NULL 
,Run_Comment04 CHAR(800) NULL 
,Run_Comment05 CHAR(800) NULL 
,Run_Comment06 CHAR(800) NULL 
,Run_Comment07 CHAR(800) NULL 
,Run_Comment08 CHAR(800) NULL 
,Run_Comment09 CHAR(800) NULL 
,Run_Comment10 CHAR(800) NULL 
,Run_Comment11 CHAR(800) NULL 
,Run_Comment12 CHAR(800) NULL 
,Run_Comment13 CHAR(800) NULL 
,Run_Comment14 CHAR(800) NULL 
,Run_Comment15 CHAR(800) NULL 
,Run_Comment16 CHAR(800) NULL 
,Run_Comment17 CHAR(800) NULL 
,Run_Comment18 CHAR(800) NULL 
,Run_Comment19 CHAR(800) NULL 
,Run_Comment20 CHAR(800) NULL 
)
with (
	 MEMORY_OPTIMIZED = ON 
	,DURABILITY = SCHEMA_ONLY
)  
