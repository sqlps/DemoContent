-- part II
-- http://www.mssqltips.com/sqlservertip/3099/understanding-sql-server-memoryoptimized-tables-hash-indexes

USE Track_TempDB
GO
INSERT INTO dbo.sample_memoryoptimizedtable_Hash(c1, c2, c3)
  SELECT 1, 1, 1
  UNION ALL
  SELECT 2, 1, 1
  UNION ALL
  SELECT 8, 1, 1
  UNION ALL
  SELECT 3, 1, 1
  UNION ALL
  SELECT 4, 1, 1
  UNION ALL
  SELECT 5, 1, 1
  UNION ALL
  SELECT 6, 1, 1
  UNION ALL
  SELECT 7, 1, 1
--------------------------------------------------
INSERT INTO dbo.sample_memoryoptimizedtable_Range(c1, c2, c3)
  SELECT 1, 1, 1
  UNION ALL
  SELECT 2, 1, 1
  UNION ALL
  SELECT 8, 1, 1
  UNION ALL
  SELECT 3, 1, 1
  UNION ALL
  SELECT 4, 1, 1
  UNION ALL
  SELECT 5, 1, 1
  UNION ALL
  SELECT 6, 1, 1
  UNION ALL
  SELECT 7, 1, 1
/*----------------------------------------------*/
/*----------------------------------------------*/
INSERT INTO dbo.StringTable_Hash(PersonID, Name)
  SELECT 'A101054', 'John'
  UNION ALL
  SELECT 'A184848', 'Tim'
  UNION ALL
  SELECT 'C154887', 'Bill'
  UNION ALL
  SELECT 'B101054', 'Henry'
  UNION ALL
  SELECT 'B109854', 'Douglas'
  UNION ALL
  SELECT 'D101054', 'Charles'
  UNION ALL
  SELECT 'CA01054', 'Ben'
--------------------------------------------------
INSERT INTO dbo.StringTable_Range(PersonID, Name)
  SELECT 'A101054', 'John'
  UNION ALL
  SELECT 'A184848', 'Tim'
  UNION ALL
  SELECT 'C154887', 'Bill'
  UNION ALL
  SELECT 'B101054', 'Henry'
  UNION ALL
  SELECT 'B109854', 'Douglas'
  UNION ALL
  SELECT 'D101054', 'Charles'
  UNION ALL
  SELECT 'CA01054', 'Ben'
/*----------------------------------------------*/
/*----------------------------------------------*/
INSERT INTO dbo.Composite_Key_Hash(c1, c2, c3)
  SELECT 1, 1, 1
  UNION ALL
  SELECT 2, 1, 1
  UNION ALL
  SELECT 8, 1, 1
  UNION ALL
  SELECT 3, 1, 1
  UNION ALL
  SELECT 4, 1, 1
  UNION ALL
  SELECT 5, 1, 1
  UNION ALL
  SELECT 6, 1, 1
  UNION ALL
  SELECT 7, 1, 1
--------------------------------------------------
INSERT INTO dbo.Composite_Key_Range(c1, c2, c3)
  SELECT 1, 1, 1
  UNION ALL
  SELECT 2, 1, 1
  UNION ALL
  SELECT 8, 1, 1
  UNION ALL
  SELECT 3, 1, 1
  UNION ALL
  SELECT 4, 1, 1
  UNION ALL
  SELECT 5, 1, 1
  UNION ALL
  SELECT 6, 1, 1
  UNION ALL
  SELECT 7, 1, 1