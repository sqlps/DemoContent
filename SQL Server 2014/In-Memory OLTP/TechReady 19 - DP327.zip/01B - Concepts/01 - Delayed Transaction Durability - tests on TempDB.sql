/* 
	This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment.� THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
	PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
	NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
	PURPOSE.� We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided that You
	agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in which
	the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product
	in which the Sample Code is embedded; 
	and	(iii) to indemnify, hold harmless, and defend Us and
	Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
	result from the use or distribution of the Sample Code.
*/

-- THIS SCRIPT:
-- 1. modifies TempDB setting to allow delayed-durability
-- 1.1 shows the new setting
-- 2. creates and starts a XEvent session that will capture Delayed-Durability
-- 3. creates an object in tempdb and inserts rows into it
-- 4. queries XEvent
-- 5. stops the XEvent session
-- 6. drops the XEvent session

-- 1:
alter database tempdb
set delayed_durability = forced;
go

-- 1.1 verifying:
select 
       name,
       delayed_durability_desc
from sys.databases
where name = 'tempdb';

-- 2. create an XEvents session by capturing the log_flush_requested event.  
create event session LogFlushRequested
on server
add event sqlserver.log_flush_requested
(
       where
       (
              database_id = 2      -- tempdb
       )
)
add target package0.event_file
(
       set 
              filename = N'D:\TEMP\LogFlushRequested.xel' 
);

alter event session LogFlushRequested
on server
state = start;
go



-- 3. This event has an event column of is_delayed_durability and while running this session I ran a quick query:
use tempdb;
go

create table myTempDbTable
(
       id int identity(1, 1) not null
);
go

begin tran;
       insert into myTempDbTable
       default values;
commit tran;

select * from myTempDBTable

-- 4. Looking at the output of the log_flush_requested event for this duration, 
--		I see that is_delayed_durability is false.  
--		So with my quick test it looks like forcing delayed durability is not in fact recognized for tempdb.  
--		But again this is a quick and isolated test.

-- Query the Event data from the Target.
-- http://sqlblog.com/blogs/jonathan_kehayias/archive/2010/12/06/an-xevent-a-day-6-of-31-targets-week-asynchronous-file-target.aspx

DECLARE @path nvarchar(260), @mdpath nvarchar(260)

-- Get the log file name and substitute * wildcard in
SELECT 
   @path = LEFT(column_value, LEN(column_value)-CHARINDEX('.', REVERSE(column_value))) 
       + '*' 
        + RIGHT(column_value, CHARINDEX('.', REVERSE(column_value))-1)
FROM sys.dm_xe_sessions s
JOIN sys.dm_xe_session_object_columns soc
    ON s.address = soc.event_session_address
WHERE s.name = 'LogFlushRequested'
  AND soc.object_name = 'event_file' -- 'asynchronous_file_target'
  AND soc.column_name = 'filename'

SELECT @path


-- Get the metadata file name and substitute * wildcard in 
SELECT 
    @mdpath = LEFT(column_value, LEN(column_value)-CHARINDEX('.', REVERSE(column_value))) 
        + '*' 
        + RIGHT(column_value, CHARINDEX('.', REVERSE(column_value))-1)
FROM sys.dm_xe_sessions s
JOIN sys.dm_xe_session_object_columns soc
    ON s.address = soc.event_session_address
WHERE s.name = 'LogFlushRequested'
  AND soc.object_name = 'asynchronous_file_target'
  AND soc.column_name = ' metadatafile'

-- Set the metadata filename if it is NULL to the log file name with xem extension
SELECT @mdpath = ISNULL(@mdpath, 
                        LEFT(@path, LEN(@path)-CHARINDEX('*', REVERSE(@path))) 
                        + '*xem')
SELECT @mdpath

SELECT
    CAST(event_data AS XML) AS event_data
 FROM sys.fn_xe_file_target_read_file(@path, @mdpath, null, null)

SELECT 
    n.value('(@name)[1]', 'varchar(50)') AS event_name,
    n.value('(@package)[1]', 'varchar(50)') AS package_name,
    n.value('(@id)[1]', 'int') AS id,
    n.value('(@version)[1]', 'int') AS version,
    DATEADD(hh, 
            DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
            n.value('(@timestamp)[1]', 'datetime2')) AS [timestamp],
    n.value('(data[@name="error"]/value)[1]', 'int') as error,
    n.value('(data[@name="severity"]/value)[1]', 'int') as severity,
    n.value('(data[@name="duration"]/value)[1]', 'int') as state,
    n.value('(data[@name="user_defined"]/value)[1]', 'varchar(5)') as user_defined,
    n.value('(data[@name="message"]/value)[1]', 'varchar(max)') as message
FROM 
(SELECT
    CAST(event_data AS XML) AS event_data
 FROM sys.fn_xe_file_target_read_file(@path, @mdpath, null, null)
) as tab
CROSS APPLY event_data.nodes('event') as q(n)


-- 5 stop the XEVENT session
alter event session LogFlushRequested
on server
state = stop;
go

-- 6 drop the XEVENT session
drop event session LogFlushRequested
on server;
go
*/
