use WideWorldImporters
go
exec regression
go