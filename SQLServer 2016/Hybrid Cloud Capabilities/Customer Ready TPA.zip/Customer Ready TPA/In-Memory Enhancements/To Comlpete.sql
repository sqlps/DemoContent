Section 2: Temporal, Hybrid and Polybase
1) Trading System
2) Stretch and backups
3) Polybase

Section 3: Security
1) Alwyas E
2) RLS and DDM


Section 4:
1) Query Store and LQS
2) AlwaysOn
3) Backup Enhancements