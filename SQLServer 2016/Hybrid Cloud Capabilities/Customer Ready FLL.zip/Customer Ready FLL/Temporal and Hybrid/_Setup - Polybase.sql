/* This Sample Code is provided for the purpose of illustration only and is not intended 
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE 
PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR 
PURPOSE.  We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
and to reproduce and distribute the object code form of the Sample Code, provided that You 
agree: (i) to not use Our name, logo, or trademarks to market Your software product in which
the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product
in which the Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and
Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or 
result from the use or distribution of the Sample Code.
*/

----------------------------------------------------------------
-- AdventureWorksDW2016CTP3 samples: PolyBase
----------------------------------------------------------------

-- This sample will show you how to query and load data from Azure blob storage
-- to AdventureWorks2016CTP3 database using PolyBase.

USE AdventureWorksDW2016CTP3
go


------------------------------- Configuration ------------------------------------------------------------------


-- Specify the type of data source you want to query. 
-- Choose Option 7 for Azure blob storage.
exec sp_configure 'hadoop connectivity', 7;
Reconfigure;

-- Restart SQL Server to set the changes. This will automatically restart
-- "SQL Server PolyBase Engine" and "SQL Server PolyBase Data Movement Service". 

-- Verify hadoop connectivity run_value is set to 7.
exec sp_configure 'hadoop connectivity';


-- STEP 1: Create a database master key to encrypt database scoped credential secret in the next step.
-- Replace <password> with a password to encrypt the master key
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'P@ssw0rd';


-- STEP 2: Create a database scoped credential to authenticate against your Azure storage account.
-- Replace the <storage_account_key> with your Azure storage account key (primary access key). 
-- To find the key, open to your storage account on Azure Portal (https://portal.azure.com/).
CREATE DATABASE SCOPED CREDENTIAL AzureStorageCredential 
WITH IDENTITY = 'StorageAccountname', 
SECRET = 'Shhhh! its a seccret. This is the key from Azure Portal';


-- STEP 3: Create an external data source to specify location and credential for your Azure storage account.
-- Replace the <container_name> with your Azure storage blob container.
-- Replace the <storage_account_name> with your Azure storage account name.

CREATE EXTERNAL DATA SOURCE AzureStorage 
WITH (	
		TYPE = Hadoop, 
		LOCATION = 'wasbs://polybase@fffffff.blob.core.windows.net',
		CREDENTIAL = AzureStorageCredential
); 




-- Step 4: Create an external file format to specify the layout of data stored in Azure blob storage. 
-- The data is in a comma-separated text file.
CREATE EXTERNAL FILE FORMAT TextFile 
WITH (
		FORMAT_TYPE = DelimitedText, 
		FORMAT_OPTIONS (FIELD_TERMINATOR = '|')
);

-- Step 5: Create an external table to reference data stored in your Azure blob storage account.
-- Specify column properties for the table.
-- Replace LOCATION: <file_path> with the relative path of your file from the blob container.
-- If the file is directly under your blob container, the location would simply be 'FactResellerSalesArchive.txt'.
CREATE EXTERNAL TABLE dbo.FactResellerSalesArchiveExternal (
	[ProductKey] [int] NOT NULL,
	[OrderDateKey] [int] NOT NULL,
	[DueDateKey] [int] NOT NULL,
	[ShipDateKey] [int] NOT NULL,
	[ResellerKey] [int] NOT NULL,
	[EmployeeKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[SalesTerritoryKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [tinyint] NOT NULL,
	[RevisionNumber] [tinyint] NULL,
	[OrderQuantity] [smallint] NULL,
	[UnitPrice] [money] NULL,
	[ExtendedAmount] [money] NULL,
	[UnitPriceDiscountPct] [float] NULL,
	[DiscountAmount] [float] NULL,
	[ProductStandardCost] [money] NULL,
	[TotalProductCost] [money] NULL,
	[SalesAmount] [money] NULL,
	[TaxAmt] [money] NULL,
	[Freight] [money] NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[CustomerPONumber] [nvarchar](25) NULL,
	[OrderDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[ShipDate] [datetime] NULL
)
WITH (
		LOCATION='FactResellerSalesArchive.txt', 
		DATA_SOURCE=AzureStorage, 
		FILE_FORMAT=TextFile
);

-- Cleanup
Drop External Table dbo.FactResellerSalesArchiveExternal
DROP EXTERNAL FILE FORMAT TextFile 
DROP EXTERNAL DATA SOURCE AzureStorage 
DROP DATABASE SCOPED CREDENTIAL AzureStorageCredential 
DROP MASTER KEY