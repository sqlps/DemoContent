Use Clinic
CREATE TABLE [dbo].[Patients](
 [PatientId] [int] IDENTITY(1,1) NOT NULL,
 [SSN] [nvarchar](11) NOT NULL,
 [FirstName] [nvarchar](50) NOT NULL,
 [LastName] [nvarchar](50) NOT NULL,
 [MiddleName] [nvarchar](50) NULL,
 [StreetAddress] [nvarchar](50) NULL,
 [City] [nvarchar](50) NULL,
 [ZipCode] [int] NULL,
 [State] [nvarchar](50) NULL,
 [BirthDate] [datetime2](7) NOT NULL,
 PRIMARY KEY CLUSTERED 
 (
 [PatientId] ASC
 ) WITH (
 PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, 
 ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
 ) ON [PRIMARY]