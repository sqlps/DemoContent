﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ElusionX.Web.Models
{
    public class OAModel
    {
        public int OrderMinute { get; set; }
        public int OrderRevenue { get; set; }
    }
}