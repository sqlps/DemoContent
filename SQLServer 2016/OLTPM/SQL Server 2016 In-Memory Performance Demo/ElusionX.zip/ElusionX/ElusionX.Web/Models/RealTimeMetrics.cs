﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ElusionX.Web.Models
{
    public class RealTimeMetrics
    {
        public int Orders { get; set; }
        public double CPU { get; set; }
    }
}