-- Unprivileged users see masked data by default. For example, this SalesPerson 'michael9' will
-- see masked data:
use AdventureWorks2016
EXECUTE AS USER = 'michael9'
SELECT * FROM Sales.CustomerPII -- EmailAddress and PhoneNumber are masked
REVERT
go