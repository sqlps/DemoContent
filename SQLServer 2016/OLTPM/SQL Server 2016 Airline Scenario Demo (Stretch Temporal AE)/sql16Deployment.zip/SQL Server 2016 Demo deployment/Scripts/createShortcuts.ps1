$ipAddress = "127.0.0.1"
$rdpaddress = "$ipAddress" + ":3389"


Write-Host("")
Write-Host("Creating WingtipSqlVM RDP file on Desktop")
Write-Host("")
"full address:s:$address
prompt for credentials:i:1 
administrative session:i:1"  | Out-File "$env:userprofile\Desktop\WingtipSqlVM.rdp"

Write-Host("Creating LaunchWingtipWeb webserver shortcut")
Write-Host("")
$sourcert = $PSScriptRoot
$destinationrt = Split-Path -Path $sourcert -Parent
$TargetFile = "$destinationrt\Artifacts\webapp\approot\web.cmd"
$ShortcutFile = "$env:Public\Desktop\LaunchWingtipWeb.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.Save()