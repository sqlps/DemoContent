param(
    [string]$parametersFilePath = "..\Artifacts\parameters.json"
)

Write-Host "Removing Stretch Database from SQL Azure"

Import-Module AzureRM.Profile
Import-Module AzureRM.Resources
Import-Module Azure

function GetAzureAccountInfo(){
    try {
        Get-AzureRmContext
    }
    catch [System.Exception] {
        Write-Host "Signing you into Azure..."
        Login-AzureRmAccount 
    }
} 

function GetSubscriptions() {
    $subs = Get-AzureRmSubscription
    $global:indexSub = 0
    $selectedIndex = -1    
    
    $formattedTable = $subs |
    Format-Table -Property @{name="Option";expression={$global:indexSub;$global:indexSub+=1}}, SubscriptionId, SubscriptionName
    
    Write-Host ($formattedTable| Out-String)
    
    if ($subs -is [system.array]) {
        if ($subs.length -eq 1) {
            return $subs[0]
        }
        while ($true)
        {  
            try
            {
                [int]$selectedIndex = Read-Host "Select an option from the above list"
            }
            catch
            {
                Write-Host "Must be a number"
                continue
            }
            
            if ($selectedIndex -lt 1 -or $selectedIndex -gt $subs.length)
            {
                continue
            }
            
            $SubscriptionId = $subs[$selectedIndex - 1]
            break
        }
        return $SubscriptionId 
    } else {
        return $subs.SubscriptionId
    }
    
}

function LoadParameters () {
    $JsonContent = Get-Content $parametersFilePath -Raw | ConvertFrom-Json
    $JsonParameters = $JsonContent | Get-Member -Type NoteProperty | Where-Object {$_.Name -eq "parameters"}
    
    if ($JsonParameters -eq $null) {
        $JsonParameters = $JsonContent
    }
    else {
        $JsonParameters = $JsonContent.parameters
    }
    
    $JsonParameters | Get-Member -Type NoteProperty | ForEach-Object {
        $ParameterValue = $JsonParameters | Select-Object -ExpandProperty $_.Name
        $Parameters[$_.Name] = $ParameterValue.value
    }
}

$Parameters = New-Object -TypeName Hashtable
LoadParameters
$resourceGroupName = $Parameters['env']
$sqlServerName = $resourceGroupName.ToLower()

GetAzureAccountInfo
$rm_subscription_id = GetSubscriptions
Select-AzureRmSubscription -SubscriptionId $rm_subscription_id | out-null

$databases = Get-AzureRmSqlDatabase -ServerName $sqlServerName -ResourceGroupName $resourceGroupName

$databases | ForEach-Object{
    $name = $_.DatabaseName
    
    if ($name -ne "master") {
        Remove-AzureRmSqlDatabase -DatabaseName $name -ServerName $sqlServerName -ResourceGroupName $resourceGroupName -Force
    }
}