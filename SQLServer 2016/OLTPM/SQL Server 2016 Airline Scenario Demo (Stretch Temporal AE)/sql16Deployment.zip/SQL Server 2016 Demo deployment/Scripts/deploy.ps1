param(
[string]$subscriptionId,
[string]$resourceGroupName,
[string]$resourceGroupLocation,
[string]$deploymentName,
[string]$templateFilePath = "template.json",
[string]$parametersFilePath = "..\Artifacts\parameters.json",
[string]$parametersTemplatePath = "parameterTemplate.json",
[string]$appsettingsTemplatePath = "appsettingsTemplate.json",
[string]$ArtifactStagingDirectory = '..\Artifacts',
[string]$AzCopyPath = '..\Tools\AzCopy.exe'
)

Write-Host 'Starting Deployment for SQL server 2016 Demo Environment'
Import-Module AzureRM.Profile
Import-Module AzureRM.Resources
Import-Module Azure

Set-StrictMode -Version 3

function RegisterResourceProviders {
    Write-Host "Registering resource providers"

    # Register RPs
    $resourceProviders = @("microsoft.compute","microsoft.network","microsoft.storage");
    if($resourceProviders.length) {
        
        foreach($resourceProvider in $resourceProviders) {
            Register-AzureRmResourceProvider -ProviderNamespace $resourceProvider -Force -WarningAction:SilentlyContinue -Verbose:$false | Out-Null
        }
    }  
}

function GetAzureAccountInfo(){
    try {
        Get-AzureRmContext
    }
    catch [System.Exception] {
        Write-Host "Signing you into Azure..."
        Login-AzureRmAccount 
    }
} 

function GetSubscriptions() {
    Write-Host "Loading subscriptions"
    $subs = Get-AzureRmSubscription
    $global:indexSub = 0
    $selectedIndex = -1    
    
    if ($subs -is [system.array]) {
        if ($subs.length -eq 1) {
            return $subs[0]
        }
        
        $formattedTable = $subs |
        Format-Table -Property @{name="Option";expression={$global:indexSub;$global:indexSub+=1}}, SubscriptionId, SubscriptionName
        
        Write-Host ($formattedTable| Out-String)
        
        while ($true)
        {  
            try
            {
                [int]$selectedIndex = Read-Host "Select an option from the above list"
            }
            catch
            {
                Write-Host "Must be a number"
                continue
            }
            
            if ($selectedIndex -lt 1 -or $selectedIndex -gt $subs.length)
            {
                continue
            }
            
            $SubscriptionId = $subs[$selectedIndex - 1]
            break
        }
        return $SubscriptionId 
    } else {
        return $subs.SubscriptionId
    }    
}

function LoadParameters () {
    $JsonContent = Get-Content $parametersFilePath -Raw | ConvertFrom-Json
    $JsonParameters = $JsonContent | Get-Member -Type NoteProperty | Where-Object {$_.Name -eq "parameters"}
    
    if ($JsonParameters -eq $null) {
        $JsonParameters = $JsonContent
    }
    else {
        $JsonParameters = $JsonContent.parameters
    }
    
    $JsonParameters | Get-Member -Type NoteProperty | ForEach-Object {
        $ParameterValue = $JsonParameters | Select-Object -ExpandProperty $_.Name
        
        if ($_.Name -eq $ArtifactsLocationName -or        $_.Name -eq $ArtifactsLocationSasTokenName) {
            $Parameters[$_.Name] = $ParameterValue.value
        }
        if ( $_.Name -eq "env" ) {
            $LocalParameters[$_.Name] = $ParameterValue.value
        }
        if ($_.Name -eq "adminPassword"){
            $Parameters[$_.Name] = ConvertTo-SecureString $ParameterValue.value -asplaintext -force             
        }
    }
}

function CreateStorageAccount () {
    Write-Host "Creating Storage Account";
    
    $d = New-AzureRmResourceGroupDeployment -Name ((Get-ChildItem 'Storage.json').BaseName +
    '-' + ((Get-Date).ToUniversalTime()).ToString('MMdd-HHmm')) `
                                        -ResourceGroupName $ResourceGroupName `
                                        -TemplateFile 'Storage.json' `
                                        -Force -Verbose `
                                        -WarningAction:SilentlyContinue
    
    $StorageAccountName = $d.Outputs['storageName'].Value
    $StorageContainerName = 'artifacts'
    
    $StorageAccountKey = (Get-AzureRmStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName).Value[0]
    $StorageAccountContext = (Get-AzureRmStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName).Context
    
    # Create container if required
    $con = Get-AzureStorageContainer -Name $StorageContainerName -Context $StorageAccountContext -ErrorAction:SilentlyContinue
    if ($con -eq $null) {
        $con = New-AzureStorageContainer -Name $StorageContainerName -Context $StorageAccountContext -Permission Blob 
    }
    
    # Convert relative paths to absolute paths if needed
    $AzCopyPath = [System.IO.Path]::Combine($PSScriptRoot, $AzCopyPath)
    $ArtifactStagingDirectory = [System.IO.Path]::Combine($PSScriptRoot, $ArtifactStagingDirectory)
    
    $ArtifactsLocation = $StorageAccountContext.BlobEndPoint + $StorageContainerName
    $Parameters[$ArtifactsLocationName] = $ArtifactsLocation
    
    Write-Host "Uploading artifacts to blob";

    # Use AzCopy to copy files from the local storage drop path to the storage account container
    & $AzCopyPath """$ArtifactStagingDirectory""", $ArtifactsLocation, "/DestKey:$StorageAccountKey", "/S", "/Y", "/Z:$env:LocalAppData\Microsoft\Azure\AzCopy\$ResourceGroupName" | Out-Null

    Write-Host "Artifacts uploaded";
    
    $ArtifactsLocationSasToken = '?'
    $ArtifactsLocationSasToken = ConvertTo-SecureString $ArtifactsLocationSasToken -AsPlainText -Force
    $Parameters[$ArtifactsLocationSasTokenName] = $ArtifactsLocationSasToken
}

$Parameters = New-Object -TypeName Hashtable
$LocalParameters = New-Object -TypeName Hashtable

Set-Variable ArtifactsLocationName '_artifactsLocation' -Option ReadOnly -Force
Set-Variable ArtifactsLocationSasTokenName '_artifactsLocationSasToken' -Option ReadOnly -Force

$Parameters.Add($ArtifactsLocationName, $null)
$Parameters.Add($ArtifactsLocationSasTokenName, $null)

LoadParameters

try {
    $script_dir = Split-Path $MyInvocation.MyCommand.Path
    gci -Recurse $script_dir | Unblock-File

    GetAzureAccountInfo

    $rm_subscription_id = GetSubscriptions

    Select-AzureRmSubscription -SubscriptionId $rm_subscription_id -WarningAction:SilentlyContinue | Out-Null 
    Write-Host "Using subscription '$rm_subscription_id'";
    
    
    do {
        $resourceGroupName = Read-Host "What is the name of deployment? Please make sure it's globally unique"
        if ($resourceGroupName.length -lt 15) {
            break;
        }

        Write-Output "Windows computer name cannot be more than 15 characters long, be entirely numeric, or contain the following characters: `` ~ ! @ # $ % ^ & * ( ) = + _ [ ] { } \ | ; : . ' `" , < > / ?."        
    }
    until ($resourceGroupName.length -lt 15)

    $caption = "Choose Region";
    $message = "Where do you want the deployment?";
    $southEastAsia = new-Object System.Management.Automation.Host.ChoiceDescription "Southeast &Asia","Southeast Asia";
    $westUS = new-Object System.Management.Automation.Host.ChoiceDescription "West &US","West US";
    $westEurope = new-Object System.Management.Automation.Host.ChoiceDescription "West &Europe","West Europe";
    $choices = [System.Management.Automation.Host.ChoiceDescription[]]($westUS, $westEurope, $southEastAsia);
    $answer = $host.ui.PromptForChoice($caption,$message,$choices,0)

    switch ($answer){
        0 {$resourceGroupLocation = "West US"; break}
        1 {$resourceGroupLocation = "West Europe"; break}
        2 {$resourceGroupLocation = "Southeast Asia"; break}
    }

    Write-Host "Deploying to $resourceGroupLocation, name: $resourceGroupName"

    (Get-Content $parametersTemplatePath).replace('[env]', $resourceGroupName) | Set-Content $parametersFilePath
    (Get-Content $parametersFilePath).replace('[loc]', $resourceGroupLocation) | Set-Content $parametersFilePath
    
    # RegisterResourceProviders 

    #Create or check for existing resource group
    $resourceGroup = Get-AzureRmResourceGroup -Name $resourceGroupName -WarningAction:SilentlyContinue -ErrorAction:SilentlyContinue
    if(!$resourceGroup)
    {
        Write-Host "Creating resource group '$resourceGroupName' in location '$resourceGroupLocation'";
        New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -WarningAction:SilentlyContinue | Out-Null
        Write-Host "Resource group '$resourceGroupName' created ";
    }
    else{
        Write-Host "Using existing resource group '$resourceGroupName'";
    }

    CreateStorageAccount 

    # Start the deployment
    Write-Host "Starting SQL Server 16 deployment...";
    New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $templateFilePath -TemplateParameterFile $parametersFilePath @Parameters -Verbose -WarningAction:SilentlyContinue

    Write-Host "Deployment complete";

    $ipResource = Get-AzureRmPublicIpAddress -Name $resourceGroupName -ResourceGroupName $resourceGroupName
    $ipAddress = $ipResource.IpAddress
    Write-Host "VM deployed to $ipAddress"

    $ArtifactStagingDirectory = [System.IO.Path]::Combine($PSScriptRoot, $ArtifactStagingDirectory)

    Remove-Item -Recurse -Force "$ArtifactStagingDirectory\webapp" -WarningAction:SilentlyContinue | Out-Null 
    Add-Type -As System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory("$ArtifactStagingDirectory\webapp.zip", "$ArtifactStagingDirectory\webapp") | Write-Verbose
    Write-Host 'Unzipped WebApp'

    $appSettingPath = "$ArtifactStagingDirectory\webapp\approot\packages\StretchWebApi\1.0.0\root\appsettings.json"
    (Get-Content $appsettingsTemplatePath).replace('[ip]', $ipResource.IpAddress) | Set-Content $appSettingPath

    Write-Host "Installing AE Certificate";
    $certPassword = ConvertTo-SecureString "password1" -asplaintext -force
    Import-PfxCertificate -FilePath "$ArtifactStagingDirectory\privatekey.pfx" cert:\currentUser\my -Password $certPassword | Out-Null
    
	$rdpAddress = "$ipAddress" + ":3389"

	Write-Host("")
	Write-Host("Creating WingtipSqlVM RDP file on Desktop")
	Write-Host("")
	"full address:s:$rdpAddress
	prompt for credentials:i:1 
	administrative session:i:1"  | Out-File "$env:userprofile\Desktop\WingtipSqlVM.rdp"

	Write-Host("Creating LaunchWingtipWeb webserver shortcut on Desktop")
	Write-Host("")
	$sourcert = $PSScriptRoot
	$destinationrt = Split-Path -Path $sourcert -Parent
	$TargetFile = "$destinationrt\Artifacts\webapp\approot\web.cmd"
	$ShortcutFile = "$env:Public\Desktop\LaunchWingtipWeb.lnk"
	$WScriptShell = New-Object -ComObject WScript.Shell
	$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
	$Shortcut.TargetPath = $TargetFile
	$Shortcut.Save()
	
    Start-Process "$ArtifactStagingDirectory\webapp\approot\web.cmd"
}
catch [System.Exception] {
    $exceptionItem = $_.Exception
    Write-Host "Error during deployment"
    Write-Host "$exceptionItem" 

    $message = "Do you want to rollback the deployment?";
    $yes = new-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Yes";
    $no = new-Object System.Management.Automation.Host.ChoiceDescription "&No","No";
    $choices = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no);
    $answer = $host.ui.PromptForChoice("",$message,$choices,0)

    switch ($answer){
        0 {
            Write-Host "Removing Resource Group: $resourceGroupName"            
            Remove-AzureRmResourceGroup -Name $resourceGroupName -Force -ErrorAction:SilentlyContinue; 
            Write-Host "Rollback complete"
            break
        }
        1 {
            Write-Host "Exiting"
        }
    }
    
}

