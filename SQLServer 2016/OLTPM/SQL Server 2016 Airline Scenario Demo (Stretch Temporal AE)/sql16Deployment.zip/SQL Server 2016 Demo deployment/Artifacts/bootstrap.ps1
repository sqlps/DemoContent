[CmdletBinding()]
param(
[string]$sqlServerName
)

function New-TempAccount {
    $r = New-Object System.Random
    
    $username = "temp$($r.Next(0, 100000))"
    $password = "Pass@word$($r.Next(0, 100000))"
    
    $computer = [ADSI]"WinNT://$env:COMPUTERNAME,Computer"
    $user = $computer.Create("User", $username)
    $user.SetPassword($password)
    $user.SetInfo()
    $user.UserFlags = 64 + 65536
    $user.SetInfo()
    $group = [ADSI]("WinNT://$env:COMPUTERNAME/Administrators,Group")
    $group.add("WinNT://$username,User")
    
    Write-Verbose "Created temporary user $username"
    @{'username' = $username; 'password' = $password}
}

function Remove-TempAccount {
    param([string]$username)
    
    $computer = [ADSI]"WinNT://$env:COMPUTERNAME,Computer"
    $computer.Delete('User', $username)
    
    Write-Verbose "Removed temporary user $username"
}

function Add-TempAccountToSql {
    param([string]$username)
    
    try {
        Stop-SqlServices
        
        Start-Job -ScriptBlock {& "$env:programfiles\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Binn\sqlservr.exe" -m}
        Sleep -Seconds 10
        
        & sqlcmd.exe -S . -Q "CREATE LOGIN [$env:COMPUTERNAME\$username] FROM WINDOWS" | Write-Verbose
        & sqlcmd.exe -S . -Q "SP_ADDSRVROLEMEMBER '$env:COMPUTERNAME\$username', 'sysadmin'" | Write-Verbose
        
        Stop-Process -ProcessName 'sqlservr'
    } finally {
        Start-SqlServices
    }
}

function Remove-TempAccountFromSql {
    param([string]$username)
    
    try {
        Stop-SqlServices
        
        Write-Verbose 'Starting SQL in single user mode'
        Start-Job -ScriptBlock {& "$env:programfiles\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\Binn\sqlservr.exe" -m}
        Sleep -Seconds 10
        
        Write-Verbose "Removing $username as SQL sysadmin"
        & sqlcmd.exe -S . -Q "DROP LOGIN [$env:COMPUTERNAME\$username]" | Write-Verbose
        
        Write-Verbose 'Stopping SQL in single user mode'
        Stop-Process -ProcessName 'sqlservr'
    } finally {
        Start-SqlServices
    }
}

function Stop-SqlServices {
    Write-Verbose 'Stopping SQL Services'
    
    do {
        & net stop MSSQLLaunchpad | Write-Verbose
        & net stop MSSQLSERVER | Write-Verbose
        
        Sleep -Seconds 10
        $proc = Get-Process -Name 'sqlservr' -ErrorAction SilentlyContinue
    } while ($proc -ne $null)
    
    Write-Verbose 'Stopped SQL Services'
}

function Start-SqlServices {
    Write-Verbose 'Starting SQL Services'
    
    & net start MSSQLSERVER | Write-Verbose
    & net start MSSQLLaunchpad | Write-Verbose
    
    Write-Verbose 'Started SQL Services'
}

function New-ScheduledTaskEx {
    param([string]$script, [string]$username, [string]$password, [string]$sqlServerName)
    
    $taskDate = ((Get-Date).AddHours(10).ToString('MM/dd/yyyy'))
    $taskTime = ((Get-Date).AddHours(10).ToString('HH:mm'))
    $taskName = [System.IO.Path]::GetFileName($script).Trim() + '-Task'
    
    
    Write-Verbose "Creating scheduled task: $taskName"
    
    $createTaskCommand =& 'C:\Windows\System32\schtasks.exe' /create /sc ONCE /tn $createTaskCommand "$taskName" /tr "powershell.exe -ExecutionPolicy Unrestricted -File $script -Verbose -sqlServerName $sqlServerName" /ru $username /rp $password /s $env:COMPUTERNAME /st $taskTime /sd $taskDate /F 
    
    Write-Verbose $createTaskCommand
    
    $taskName
}

function Remove-ScheduledTask {
    param([string]$taskName)
    
    Write-Verbose "Removing scheduled task: $taskName"
    & 'C:\Windows\System32\schtasks.exe' /delete /tn "$taskName" /f | Write-Verbose
}

function Wait-ScheduledTask {
    param([string]$taskName)
    
    $waitAttempts = 0
    do {
        $taskDetails = Get-ScheduledTask -TaskName $taskName
        if($taskDetails.State -eq 'Running') {
            $waitAttempts += 1
            if ($waitAttempts -ge 120) {
                throw 'Task failed to complete within the maximum wait time frame'
            } else {
                Write-Verbose 'Waiting for scheduled task to complete...'
                Start-Sleep 30
            }
        }
    } while ($taskDetails.State -eq 'Running')
    
    $taskLastRuntimeInfo = Get-ScheduledTaskInfo -TaskName $taskName
    $taskLastRuntimeDate = $taskLastRuntimeInfo.LastRunTime
    $taskLastRuntimeExitCode = $taskLastRuntimeInfo.LastTaskResult
    if ($taskLastRuntimeExitCode -ne 0) {
        throw 'Failed executing the last setup task with exit code non zero. Please review details in task scheduler.'
    } else {
        Write-Verbose 'Scheduled task completed'
    }
}

try {
    Start-Transcript -Path "$env:TEMP\bootstrap.ps1.log"
    
    # Wait for completion
    while ($true) { 
        $proc = Get-Process -Name 'setup' -ErrorAction SilentlyContinue
        if ($proc -eq $null) {
            break
        }
        
        Sleep -Seconds 10
    }
    
    $a = New-TempAccount
    Add-TempAccountToSql $a.username
    
    mkdir 'C:\Artifacts' | Write-Verbose
    Copy-Item -Path $PSScriptRoot\* -Destination 'C:\Artifacts' -Recurse 
    
    $taskName = New-ScheduledTaskEx "$PSScriptRoot\config.ps1" $a.username $a.password $sqlServerName
    Start-ScheduledTask -TaskName $taskName
    Wait-ScheduledTask $taskName
} finally {
    if ($a -ne $null) {
        Remove-TempAccountFromSql $a.username
        Remove-TempAccount $a.username
    }
    
    if ($taskName -ne $null) {
        Remove-ScheduledTask $taskName
    }
    
    Stop-Transcript
}
