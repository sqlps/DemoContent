Write-Host "Disable Stretch on local server"
& sqlcmd.exe -S . -i "disableStretch.sql"
