USE [stretchdemodb]
GO

EXEC sp_configure 'remote data archive' , '1';
GO
RECONFIGURE;
GO

DROP DATABASE SCOPED CREDENTIAL scopedCred
GO 

DROP MASTER KEY;
GO

CREATE MASTER KEY ENCRYPTION BY PASSWORD=$(serverPassword)

CREATE DATABASE SCOPED CREDENTIAL scopedCred
    WITH IDENTITY=$(serverUsername), SECRET=$(serverPassword)
GO
