[CmdletBinding()]
param(
    [string]$sqlServerName,
    [string]$artifactPath = 'C:\Artifacts',
    [string]$parametersFilePath = "$artifactPath\parameters.json"
)

$DesktopPath = [Environment]::GetFolderPath("Desktop")

function LoadParameters () {
    $JsonContent = Get-Content $parametersFilePath -Raw | ConvertFrom-Json
    
    $JsonParameters = $JsonContent | Get-Member -Type NoteProperty | Where-Object {$_.Name -eq "parameters"}
    
    if ($JsonParameters -eq $null) {
        $JsonParameters = $JsonContent
    }
    else {
        $JsonParameters = $JsonContent.parameters
    }
    
    $JsonParameters | Get-Member -Type NoteProperty | ForEach-Object {
        $ParameterValue = $JsonParameters | Select-Object -ExpandProperty $_.Name
        
        $Parameters[$_.Name] = $ParameterValue.value
    }
}

try {
    Add-Type -As System.IO.Compression.FileSystem
    Start-Transcript -Path "$env:TEMP\config.ps1.log"
    
    Import-Module sqlps
    
    # Enable Advanced Analytics
    Write-Verbose 'Installing SQL extensions'
    
    # $installSqlExtensionCommand = 
    
    # Write-Verbose $installSqlExtensionCommand
    & C:\SQLServer_13.0_Full\setup.exe /Q /ACTION=Install /INSTANCENAME=MSSQLSERVER /FEATURES=AdvancedAnalytics /IAcceptSQLServerLicenseTerms
    
    # Enable mixed auth
    Write-Verbose 'Enabled SA account'
    & sqlcmd.exe -S . -Q "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2"
    
    # Enable SA login
    & sqlcmd.exe -S . -Q "ALTER LOGIN sa ENABLE; ALTER LOGIN sa WITH PASSWORD='Pass@word2'" 
    
    # Enable remote access
    Write-Verbose 'Opening firewall for SQL'
    New-NetFirewallRule -DisplayName "SQL Server" -Direction Inbound -Protocol TCP -LocalPort 1433 -Action allow
    
    # Restart to apply new config
    Write-Verbose 'Restarting SQL'
    & net stop MSSQLLaunchpad | Write-Verbose
    & net stop MSSQLSERVER | Write-Verbose
    & net start MSSQLSERVER | Write-Verbose
    & net start MSSQLLaunchpad | Write-Verbose
    
    mkdir 'C:\Demo' | Write-Verbose
    
    wget "https://onedrive.live.com/download?cid=62632104CD4D62B9&resid=62632104CD4D62B9%21107&authkey=AMZVNhwS96IO_Ik" -outfile "$artifactPath\stretchdemodb.zip" | Write-Verbose

    [System.IO.Compression.ZipFile]::ExtractToDirectory("$artifactPath\stretchdemodb.zip", "$artifactPath") | Write-Verbose
    
    & sqlcmd.exe -S . -Q "RESTORE DATABASE [stretchdemodb] FROM DISK = N'$artifactPath\stretchdemodb.bak' WITH FILE = 1, MOVE N'stretchdemodb' TO N'$artifactPath\stretchdemodb.mdf', MOVE N'stretchdemodb_log' TO N'$artifactPath\stretchdemodb_log.ldf', NOUNLOAD, REPLACE, STATS = 10" | Write-Verbose

    $Parameters = New-Object -TypeName Hashtable
    LoadParameters
    $serverLocation = $sqlServerName + '.database.windows.net'
    $password = $Parameters['adminPassword']
    $username = $Parameters['adminName']
    
    $enableStretchPsPath = "$artifactPath\enableStretch.ps1"
    $disableStretchPsPath = "$artifactPath\disableStretch.ps1"
    
    $enableStretchPath = "$artifactPath\enableStretch.sql"
    $disableStretchPath = "$artifactPath\disableStretch.sql"

    $enableStretchContent = (Get-Content $enableStretchPsPath | Out-String);
    $enableStretchContent = $enableStretchContent.replace('[serverName]', $serverLocation);
    $enableStretchContent = $enableStretchContent.replace('[serverUsername]', $username);
    $enableStretchContent = $enableStretchContent.replace('[serverPassword]', $password);
    Set-Content -Path $enableStretchPsPath -Value $enableStretchContent;
    
    Copy-Item -Path $enableStretchPsPath -Destination $DesktopPath
    Copy-Item -Path $disableStretchPsPath -Destination $DesktopPath
    Copy-Item -Path $enableStretchPath -Destination $DesktopPath
    Copy-Item -Path $disableStretchPath -Destination $DesktopPath

    & sqlcmd.exe -S . -i "$artifactPath\setup.sql" -v serverName="'$serverLocation'" serverUsername="'$username'" serverPassword="'$password'"
    & sqlcmd.exe -S . -i $enableStretchPath -v serverName="'$serverLocation'" serverUsername="'$username'" serverPassword="'$password'"
} finally {
    Stop-Transcript
}
