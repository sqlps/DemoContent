# Would want to inject all the old data here

# Names in square brackets are replaced from config.ps1
& sqlcmd.exe -S . -i "enableStretch.sql" -v serverName="'[serverName]'" serverUsername="'[serverUsername]'" serverPassword="'[serverPassword]'"
