USE [stretchdemodb]
GO

-- Might want to change the setting here depending on whether data has to persist
ALTER TABLE dbo.ActivityHistory SET ( REMOTE_DATA_ARCHIVE ( MIGRATION_STATE = INBOUND ) )
GO
ALTER TABLE dbo.Transactions SET (  REMOTE_DATA_ARCHIVE ( MIGRATION_STATE = INBOUND ) )
GO
ALTER TABLE dbo.FlightFeedEtdHistory SET (  REMOTE_DATA_ARCHIVE ( MIGRATION_STATE = INBOUND ) )
GO

ALTER DATABASE [stretchdemodb]
    SET REMOTE_DATA_ARCHIVE = OFF ;
GO