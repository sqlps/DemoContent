USE [stretchdemodb]
GO

CREATE FUNCTION dbo.fn_stretch_by_dateactivity1(@dtDate datetime)
RETURNS TABLE
WITH SCHEMABINDING 
AS RETURN SELECT 1 AS is_eligible WHERE @dtDate < CONVERT(datetime, '2014-01-01 00:00:00.000', 110)
GO

create function dbo.fn_stretch_by_trans(@point varchar)
returns table
with schemabinding 
as return select 1 as is_eligible where @point != '-'
go

ALTER DATABASE stretchdemodb
    SET REMOTE_DATA_ARCHIVE = ON
        (
            SERVER = $(serverName),
            CREDENTIAL = scopedCred
        );

 ALTER TABLE dbo.ActivityHistory SET ( REMOTE_DATA_ARCHIVE = ON (
	FILTER_PREDICATE = dbo.fn_stretch_by_dateactivity1(LandedActual),
	MIGRATION_STATE = OUTBOUND
) )
 
 ALTER TABLE dbo.Transactions SET ( REMOTE_DATA_ARCHIVE = ON (
    FILTER_PREDICATE = dbo.fn_stretch_by_trans(Points),
	MIGRATION_STATE = OUTBOUND
) )

 ALTER TABLE dbo.FlightFeedEtdHistory SET ( REMOTE_DATA_ARCHIVE = ON (
	MIGRATION_STATE = OUTBOUND
) )

