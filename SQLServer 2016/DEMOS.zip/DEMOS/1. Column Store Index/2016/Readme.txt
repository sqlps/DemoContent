The sample requires the base AdventureWorksDW2016CTP3 database, available on Codeplex

1. Restore the AdventureworksDW2016CTP3
2. Use the ColumnstoreDemo.sql script to walk through some examples

