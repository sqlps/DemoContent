﻿
create proc Demo_Reset
as
TRUNCATE TABLE dbo.TicketReservationDetail;
