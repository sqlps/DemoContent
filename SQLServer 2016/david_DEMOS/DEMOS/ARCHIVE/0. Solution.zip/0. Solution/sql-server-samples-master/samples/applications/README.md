# Application samples

Applications that are built on Microsoft SQL databases, including SQL Server, Azure SQL Database, and Azure SQL Data Warehouse.
