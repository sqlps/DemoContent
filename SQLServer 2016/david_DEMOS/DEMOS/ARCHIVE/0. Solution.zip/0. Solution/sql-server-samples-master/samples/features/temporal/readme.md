# Samples that use Temporal functionalities that are available in SQL Server 2016 (or higher) and Azure SQL Database

[Product catalog](product-catalog)

This project contains an example implementation product catalog implemented using ASP.NET Core web aplication. You can learn how to build temporal application using new functionalities that are available in SQL Server 2016 (or higher) and Azure SQL Database.

