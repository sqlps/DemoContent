## Windows Containers
This includes samples for setting up mssql-server in Windows Containers. Currently it includes the following:
- __[mssql-server-2014-express-windows] (mssql-server-2014-express-windows/)__
