# R Services

Placeholder.

For now, refer to:
[https://github.com/Microsoft/SQL-Server-R-Services-Samples] (https://github.com/Microsoft/SQL-Server-R-Services-Samples)
