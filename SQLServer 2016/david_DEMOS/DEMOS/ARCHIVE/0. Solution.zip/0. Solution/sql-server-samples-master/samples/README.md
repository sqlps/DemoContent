# Sample Categories

__[applications] (applications/)__

End-to-end sample applications that illustrate the use of SQL Server for specific application scenarios.

__[databases] (databases/)__

Sample databases for SQL Server, Azure SQL Database, and Azure SQL Data Warehouse.

__[features] (features/)__

Samples illustrating specific SQL Server and Azure SQL Database features, including In-Memory OLTP, Master Data Services (MDS), and R Services.

__[management] (manage/)__

Samples that help with the management of SQL Server and Azure SQL Database.
