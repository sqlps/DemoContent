This content was moved:

[applications/iot-smart-grid] (/samples/applications/iot-smart-grid/)
