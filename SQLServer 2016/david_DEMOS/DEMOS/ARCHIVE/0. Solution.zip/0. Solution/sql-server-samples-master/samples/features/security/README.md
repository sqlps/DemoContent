#SQL Security

<!--laceholder for summary.--> 

[Azure Active Directory Authentication Demos](azure-active-directory-auth)

[Azure SQL Security Demo](https://github.com/Microsoft/azure-sql-security-sample) 

[SQL 2016 Security Demo](contoso-clinic)
