-- Enable Enterprise Edition features (also available in Evaluation/Developer Edition) 

USE WideWorldImporters;
GO

SET NOCOUNT ON;

EXECUTE [Application].Configuration_ConfigureForEnterpriseEdition
GO

