﻿CREATE SEQUENCE [dbo].[TicketReservationSequence]
    AS INT
    START WITH 1
    INCREMENT BY 1
    CACHE 50000;

