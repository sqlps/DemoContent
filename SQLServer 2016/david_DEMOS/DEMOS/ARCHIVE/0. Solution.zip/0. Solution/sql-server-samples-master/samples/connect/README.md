# Database connection samples

Contains samples that show how to connect to Microsoft SQL databases, including SQL Server, Azure SQL Database, and Azure SQL Data Warehouse from different langauges like:
* Python
* .Net
* Java
* Ruby
* Node.js

